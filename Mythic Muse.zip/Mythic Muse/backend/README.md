# D&D 5e AI Assistant Backend

Node.js + Express backend for the D&D AI Assistant web app.  
Provides JSON APIs for:

- User auth (email/password + JWT)
- Session (campaign) creation and joining via invite key
- Character creation and management (including HP updates)
- DM tools:
  - Creature generator
  - Magic item generator
  - Encounter generator
  - Shop generator
  - Level-up advice

All AI content is **D&D 5e-inspired homebrew**, with prompts tuned to keep
things balanced and rules-like.

## Setup

1. Install dependencies:

   ```bash
   npm install
   ```

2. Copy the env file and fill in your values:

   ```bash
   cp .env.example .env
   ```

   Set at least:

   - `OPENAI_API_KEY`
   - Optionally adjust `FRONTEND_URL`, `JWT_SECRET`.

3. Run in development:

   ```bash
   npm run dev
   ```

4. Or run in production:

   ```bash
   npm start
   ```

## Health & Test Endpoints

- `GET /`  
  Health check. Returns a JSON object confirming the server is running.

- `GET /api/test/creature`  
  Confirms creature routes are mounted (no OpenAI call).

- `GET /api/test/encounter`  
  Confirms encounter routes are mounted (no OpenAI call).

These are useful to verify routing is working before testing AI endpoints.

## Key API Routes (JSON Only)

### Auth

- `POST /api/auth/register`
  - Body: `{ "email": string, "password": string }`
  - Response: `{ success, user, token }`

- `POST /api/auth/login`
  - Body: `{ "email": string, "password": string }`
  - Response: `{ success, user, token }`

Use the `token` as a Bearer token in `Authorization` header for protected routes.

### Sessions

All session routes require `Authorization: Bearer <token>`.

- `POST /api/sessions`
  - Body: `{ "name": string }`
  - Creates a new DM session with a permanent invite key.

- `GET /api/sessions`
  - Lists sessions where the user is DM or a player.

- `POST /api/sessions/join`
  - Body: `{ "inviteKey": string }`
  - Joins a session by invite key.

### Characters

All character routes require auth.

- `POST /api/characters`
  - Body: `{ "sessionId", "name", "race", "class", "subclass", "level" }`
  - Creates a character tied to the current user and session.

- `GET /api/characters/session/:sessionId`
  - Lists characters in a given session.

- `GET /api/characters/mine`
  - Lists characters owned by the current user.

- `GET /api/characters/:id`
  - Gets a single character.

- `PUT /api/characters/:id`
  - Updates a character sheet (general fields).

- `PATCH /api/characters/:id/hp`
  - Body: `{ "currentHp"?: number, "tempHp"?: number }`
  - Updates HP fields for the HP calculator.

- `POST /api/characters/:id/items`
  - DM-style "loot transfer" endpoint to add items to a character inventory.

### Generators (AI)

- `POST /api/creatures/generate`
  - Body: `{ "cr"?: number | string, "archetype"?: string, "flavor"?: string }`
  - Returns a normalized 5e-style creature stat block.

- `POST /api/items/generate`
  - Body: `{ "rarity"?: string, "slot"?: string, "theme"?: string }`
  - Returns a balanced, homebrew magic item.

- `POST /api/encounters/generate`
  - Body: `{ "partyLevel"?: number, "partySize"?: number, "difficulty"?: string, "biome"?: string, "theme"?: string }`
  - Returns an encounter with creatures, tactics, and treasure hooks.

- `POST /api/shops/generate`
  - Body: `{ "tier"?: string, "goldBudget"?: number, "itemTypes"?: string[] | string, "theme"?: string }`
  - Returns a themed shop inventory.

- `POST /api/levelup/advice`
  - Body: `{ "currentLevel"?: number, "characterClass"?: string, "subclass"?: string, "partyRole"?: string, "preferences"?: string }`
  - Returns guidance for leveling up (features, spells, feats, playstyle tips).

## CR Handling

The backend accepts CR as:

- Numbers: `0, 0.125, 0.5, 1, 2, ...`
- Strings: `"1/8"`, `"1/4"`, `"1/2"`, `"2"`, `" 1 / 8 "`

Internally, all CR values are normalized to decimals so you don't have to
manually convert fractions on the frontend.
