import { normalizeCR } from "../utils/crTools.js";

function numOrDefault(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

export function normalizeCreature(raw = {}) {
  const abilities = raw.abilities || raw.stats || {};

  const averageHP =
    raw.hitPoints?.average ??
    raw.hp?.average ??
    raw.hp ??
    1;

  const creature = {
    name: raw.name || "Unknown Creature",

    cr: normalizeCR(raw.cr ?? raw.challenge_rating ?? 0),

    size: raw.size || "Medium",
    type: raw.type || "unknown",
    alignment: raw.alignment || "unaligned",

    armorClass: numOrDefault(raw.armorClass ?? raw.ac ?? 10, 10),

    hitPoints: {
      average: numOrDefault(averageHP, 1),
      formula:
        raw.hitPoints?.formula ||
        raw.hp?.formula ||
        raw.hit_dice ||
        "1d8+0"
    },

    // ✅ These must exist for HPTracker to function correctly
    currentHp: numOrDefault(
      raw.currentHp ?? averageHP,
      1
    ),

    tempHp: numOrDefault(
      raw.tempHp ?? 0,
      0
    ),

    speed: {
      walk: raw.speed?.walk ?? raw.speed?.land ?? raw.speed ?? "30 ft.",
      fly: raw.speed?.fly || null,
      swim: raw.speed?.swim || null,
      climb: raw.speed?.climb || null,
      burrow: raw.speed?.burrow || null
    },

    abilities: {
      str: numOrDefault(abilities.str ?? abilities.Str ?? 10, 10),
      dex: numOrDefault(abilities.dex ?? abilities.Dex ?? 10, 10),
      con: numOrDefault(abilities.con ?? abilities.Con ?? 10, 10),
      int: numOrDefault(abilities.int ?? abilities.Int ?? 10, 10),
      wis: numOrDefault(abilities.wis ?? abilities.Wis ?? 10, 10),
      cha: numOrDefault(abilities.cha ?? abilities.Cha ?? 10, 10)
    },

    savingThrows: raw.savingThrows || raw.saves || {},
    skills: raw.skills || {},
    senses: raw.senses || [],
    languages: raw.languages || [],

    traits: Array.isArray(raw.traits) ? raw.traits : [],
    actions: Array.isArray(raw.actions) ? raw.actions : [],
    reactions: Array.isArray(raw.reactions) ? raw.reactions : [],
    legendaryActions: Array.isArray(raw.legendaryActions || raw.legendary_actions)
      ? raw.legendaryActions || raw.legendary_actions
      : [],

    environmentTags: raw.environmentTags || raw.tags || []
  };

  return creature;
}
