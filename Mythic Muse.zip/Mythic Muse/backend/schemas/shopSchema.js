// backend/schemas/shopSchema.js

import { normalizeItem } from "./itemSchema.js";

export function normalizeShop(raw = {}) {
  return {
    name: raw.name || "Magic Shop",
    tier: raw.tier || "mid",
    goldBudget: raw.goldBudget || 0,
    theme: raw.theme || null,

    items: Array.isArray(raw.items)
      ? raw.items.map((it) => {
          const normalized = normalizeItem(it || {});
          return {
            ...normalized,
            // Preserve any explicit price, fall back to value.gp
            price: typeof it.price === "number"
              ? it.price
              : normalized.value?.gp || 0
          };
        })
      : []
  };
}
