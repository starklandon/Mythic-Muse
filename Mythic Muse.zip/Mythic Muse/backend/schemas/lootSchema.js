// backend/schemas/lootSchema.js

import { normalizeItem } from "./itemSchema.js";

/**
 * Normalize a loot bundle returned from the OpenAI loot generator.
 * Ensures we always return a predictable structure and that each
 * item matches the same normalized item schema used elsewhere.
 */
export function normalizeLoot(raw = {}) {
  const goldBudget =
    typeof raw.goldBudget === "number" ? raw.goldBudget : 0;

  // Optional summary / notes about the loot
  const summary = raw.summary || null;

  const estimatedValue =
    raw.estimatedValue && typeof raw.estimatedValue === "object"
      ? {
          gp:
            typeof raw.estimatedValue.gp === "number"
              ? raw.estimatedValue.gp
              : 0,
          notes: raw.estimatedValue.notes || ""
        }
      : { gp: 0, notes: "" };

  const items = Array.isArray(raw.items)
    ? raw.items.map((it) => normalizeItem(it || {}))
    : [];

  return {
    goldBudget,
    summary,
    estimatedValue,
    items
  };
}
