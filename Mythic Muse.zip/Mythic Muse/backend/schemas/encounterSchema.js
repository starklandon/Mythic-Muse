import { normalizeCR } from "../utils/crTools.js";

function normalizeCreatureEntry(c = {}) {
  return {
    name: c.name || "Unknown Creature",
    count: Number.isFinite(Number(c.count)) ? Number(c.count) : 1,
    role: c.role || null,

    // CORE MONSTER FIELDS
    cr: normalizeCR(c.cr ?? c.challenge_rating ?? 0),
    size: c.size || "Medium",
    type: c.type || "unknown",
    alignment: c.alignment || "unaligned",

    armorClass: c.armorClass ?? c.armor_class ?? 10,

    hitPoints: c.hitPoints || {
      average: c.hit_points || 1,
      formula: c.hit_dice || "1d4"
    },

    speed: c.speed || {
      walk: "30 ft.",
      fly: null,
      swim: null,
      climb: null,
      burrow: null
    },

    abilities: c.abilities || {
      str: c.str || 10,
      dex: c.dex || 10,
      con: c.con || 10,
      int: c.int || 10,
      wis: c.wis || 10,
      cha: c.cha || 10
    },

    savingThrows: c.savingThrows || {},
    skills: c.skills || {},
    senses: c.senses || [],
    languages: c.languages || [],

    traits: Array.isArray(c.traits) ? c.traits : [],
    actions: Array.isArray(c.actions) ? c.actions : [],
    reactions: Array.isArray(c.reactions) ? c.reactions : [],
    legendaryActions: Array.isArray(c.legendaryActions)
      ? c.legendaryActions
      : []
  };
}

export function normalizeEncounter(raw = {}) {
  return {
    name: raw.name || "Encounter",
    theme: raw.theme || null,
    environment: raw.environment || raw.biome || null,
    difficulty: raw.difficulty || "medium",

    party: raw.party || {
      level: raw.partyLevel || 1,
      size: raw.partySize || 4
    },

    creatures: Array.isArray(raw.creatures)
      ? raw.creatures.map((c) => normalizeCreatureEntry(c))
      : [],

    tactics: raw.tactics || "",
    treasure: raw.treasure || [],
    notes: raw.notes || ""
  };
}
