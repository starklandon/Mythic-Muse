function numOrDefault(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

export function normalizeCharacter(raw = {}) {
  return {
    name: raw.name || "Unnamed Hero",
    race: raw.race || "Human",
    class: raw.class || "Fighter",
    subclass: raw.subclass || null,
    level: numOrDefault(raw.level ?? 1, 1),
    abilityScores: {
      str: numOrDefault(raw.abilityScores?.str ?? 10, 10),
      dex: numOrDefault(raw.abilityScores?.dex ?? 10, 10),
      con: numOrDefault(raw.abilityScores?.con ?? 10, 10),
      int: numOrDefault(raw.abilityScores?.int ?? 10, 10),
      wis: numOrDefault(raw.abilityScores?.wis ?? 10, 10),
      cha: numOrDefault(raw.abilityScores?.cha ?? 10, 10)
    },
    maxHp: numOrDefault(raw.maxHp ?? 10, 10),
    currentHp: numOrDefault(raw.currentHp ?? raw.maxHp ?? 10, 10),
    tempHp: numOrDefault(raw.tempHp ?? 0, 0),
    armorClass: numOrDefault(raw.armorClass ?? 10, 10),
    speed: numOrDefault(raw.speed ?? 30, 30),
    proficiencyBonus: numOrDefault(raw.proficiencyBonus ?? 2, 2),
    spellcasting: raw.spellcasting || {
      spellcastingClass: null,
      spellSlots: {},
      knownSpells: [],
      preparedSpells: []
    },
    inventory: Array.isArray(raw.inventory) ? raw.inventory : [],
    notes: raw.notes || ""
  };
}
