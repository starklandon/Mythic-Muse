function numOrDefault(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

export function normalizeItem(item = {}) {
  // Support both legacy and new armor fields
  const rawArmorClass =
    item.armorClass ??
    item.ac ??
    item.armor?.armorClass ??
    item.armor?.baseAC ??
    null;

  const rawStrengthReq =
    item.strengthRequirement ??
    item.armor?.strengthRequirement ??
    item.armor?.strRequirement ??
    null;

  return {
    name: item.name || "Unknown Item",
    type: item.type || "Unknown",
    rarity: item.rarity || "common",

    // Weapon damage (if applicable)
    baseDamage: item.baseDamage || null,
    magicalDamage: item.magicalDamage || null,

    // Armor fields (null / false for non-armor items)
    armorClass: rawArmorClass != null ? numOrDefault(rawArmorClass, 0) : null,
    armorCategory:
      item.armorCategory ||
      item.armor?.category ||
      item.armor?.type ||
      null,
    requiresStrength:
      item.requiresStrength ??
      item.armor?.requiresStrength ??
      (rawStrengthReq != null ? true : false) ??
      false,
    strengthRequirement:
      rawStrengthReq != null ? numOrDefault(rawStrengthReq, 0) : null,
    stealthDisadvantage:
      item.stealthDisadvantage ??
      item.armor?.stealthDisadvantage ??
      false,

    attunement: item.attunement ?? false,
    slot: item.slot || null,
    description: item.description || "",

    spellEffects: item.spellEffects || null,

    mechanicalEffects: Array.isArray(item.mechanicalEffects)
      ? item.mechanicalEffects
      : item.mechanicalEffects
      ? [String(item.mechanicalEffects)]
      : [],

    tags: Array.isArray(item.tags)
      ? item.tags
      : item.tags
      ? [String(item.tags)]
      : [],

    value: item.value || { gp: 0, notes: "" },
    charges: item.charges ?? null,
    consumable: item.consumable ?? false,
    stackable: item.stackable ?? false
  };
}
