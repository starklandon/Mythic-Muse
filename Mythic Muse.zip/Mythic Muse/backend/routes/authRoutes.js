import express from "express";
import crypto from "crypto";
import { createUser, findUserByEmail } from "../models/userStore.js";
import { signToken } from "../utils/authMiddleware.js";

const router = express.Router();

// Very simple password hashing using sha256 for demo.
// For real production, use bcrypt or argon2.
function hashPassword(password) {
  return crypto.createHash("sha256").update(password).digest("hex");
}

router.post("/register", (req, res, next) => {
  try {
    const { email, password } = req.body || {};
    if (!email || !password) {
      return res.status(400).json({ error: "Email and password are required" });
    }

    const passwordHash = hashPassword(password);
    const user = createUser({ email, passwordHash });
    const token = signToken(user);

    res.json({
      success: true,
      user: { id: user.id, email: user.email },
      token
    });
  } catch (err) {
    next(err);
  }
});

router.post("/login", (req, res, next) => {
  try {
    const { email, password } = req.body || {};
    if (!email || !password) {
      return res.status(400).json({ error: "Email and password are required" });
    }

    const user = findUserByEmail(email);
    if (!user) {
      return res.status(401).json({ error: "Invalid credentials" });
    }

    const passwordHash = hashPassword(password);
    if (passwordHash !== user.passwordHash) {
      return res.status(401).json({ error: "Invalid credentials" });
    }

    const token = signToken(user);
    res.json({
      success: true,
      user: { id: user.id, email: user.email },
      token
    });
  } catch (err) {
    next(err);
  }
});

export default router;
