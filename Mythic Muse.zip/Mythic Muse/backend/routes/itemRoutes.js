import express from "express";
import { generateItem } from "../utils/openaiHelpers.js";

const router = express.Router();

router.post("/generate", async (req, res, next) => {
  try {
    const { rarity, slot, theme } = req.body || {};
    const item = await generateItem({ rarity, slot, theme });

    res.json({
      success: true,
      item
    });
  } catch (err) {
    next(err);
  }
});

export default router;
