import express from "express";
import { generateLevelupAdvice } from "../utils/openaiHelpers.js";

const router = express.Router();

router.post("/advice", async (req, res, next) => {
  try {
    const {
      currentLevel,
      characterClass,
      subclass,
      partyRole,
      preferences
    } = req.body || {};

    const advice = await generateLevelupAdvice({
      currentLevel,
      characterClass,
      subclass,
      partyRole,
      preferences
    });

    res.json({
      success: true,
      advice
    });
  } catch (err) {
    next(err);
  }
});

export default router;
