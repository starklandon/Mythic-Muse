import express from "express";
import { generateCreature } from "../utils/openaiHelpers.js";

const router = express.Router();

// Simple GET test (no AI) to verify the route is mounted
router.get("/test", (req, res) => {
  res.json({ success: true, message: "Creature routes are mounted" });
});

router.post("/generate", async (req, res, next) => {
  try {
    const { cr, archetype, flavor } = req.body || {};
    const creature = await generateCreature({ cr, archetype, flavor });

    res.json({
      success: true,
      creature
    });
  } catch (err) {
    next(err);
  }
});

export default router;
