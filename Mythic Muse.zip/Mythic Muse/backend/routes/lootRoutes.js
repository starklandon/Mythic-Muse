import express from "express";
import { generateLoot } from "../utils/openaiHelpers.js";

const router = express.Router();

/**
 * POST /api/loot/generate
 *
 * Body: { goldBudget?: number, theme?: string }
 * Generates a small bundle of random loot items using the same
 * normalized item schema as the magic item and shop generators.
 */
router.post("/generate", async (req, res, next) => {
  try {
    const { goldBudget, theme } = req.body || {};

    const loot = await generateLoot({
      goldBudget,
      theme
    });

    res.json({
      success: true,
      loot
    });
  } catch (err) {
    next(err);
  }
});

export default router;
