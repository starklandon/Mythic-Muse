import express from "express";
import { generateEncounter } from "../utils/openaiHelpers.js";

const router = express.Router();

// Simple GET test (no AI) to verify the route is mounted
router.get("/test", (req, res) => {
  res.json({ success: true, message: "Encounter routes are mounted" });
});

router.post("/generate", async (req, res, next) => {
  try {
    const {
      partyLevel,
      partySize,
      difficulty,
      biome,
      theme
    } = req.body || {};

    const encounter = await generateEncounter({
      partyLevel,
      partySize,
      difficulty,
      biome,
      theme
    });

    res.json({
      success: true,
      encounter
    });
  } catch (err) {
    next(err);
  }
});

export default router;
