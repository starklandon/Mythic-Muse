import express from "express";
import {
  getPlayerInventory,
  addItemToPlayerInventory,
  clearPlayerInventory
} from "../models/playerInventoryStore.js";

const router = express.Router();

/**
 * GET /api/player-inventory
 * Returns the current in-memory player inventory.
 */
router.get("/", (req, res) => {
  res.json({
    success: true,
    inventory: getPlayerInventory()
  });
});

/**
 * POST /api/player-inventory/transfer
 *
 * Body: { item: ItemLike }
 * Appends the provided item to the shared player inventory.
 */
router.post("/transfer", (req, res, next) => {
  try {
    const { item } = req.body || {};
    if (!item) {
      const err = new Error("Missing 'item' in request body.");
      err.status = 400;
      throw err;
    }

    const added = addItemToPlayerInventory(item);

    res.json({
      success: true,
      item: added,
      inventory: getPlayerInventory()
    });
  } catch (err) {
    next(err);
  }
});

/**
 * DELETE /api/player-inventory
 * Clears the in-memory inventory (optional helper).
 */
router.delete("/", (req, res) => {
  clearPlayerInventory();
  res.json({ success: true, inventory: getPlayerInventory() });
});

export default router;
