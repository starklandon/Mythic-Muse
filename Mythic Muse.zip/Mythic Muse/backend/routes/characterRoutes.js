import express from "express";
import { authenticate } from "../utils/authMiddleware.js";
import {
  createCharacter,
  getCharactersForSession,
  getCharactersForUser,
  findCharacterById,
  updateCharacter,
  updateCharacterHp,
  addItemToCharacter
} from "../models/characterStore.js";

const router = express.Router();

router.use(authenticate);

// Create a character for a session
router.post("/", (req, res, next) => {
  try {
    const { sessionId, name, race, class: charClass, subclass, level } = req.body || {};
    if (!sessionId) {
      return res.status(400).json({ error: "sessionId is required" });
    }
    const character = createCharacter({
      userId: req.user.id,
      sessionId,
      name,
      race,
      charClass,
      subclass,
      level
    });
    res.json({ success: true, character });
  } catch (err) {
    next(err);
  }
});

// Get characters for a session
router.get("/session/:sessionId", (req, res, next) => {
  try {
    const { sessionId } = req.params;
    const characters = getCharactersForSession(sessionId);
    res.json({ success: true, characters });
  } catch (err) {
    next(err);
  }
});

// Get characters for current user
router.get("/mine", (req, res, next) => {
  try {
    const characters = getCharactersForUser(req.user.id);
    res.json({ success: true, characters });
  } catch (err) {
    next(err);
  }
});

// Get single character
router.get("/:id", (req, res, next) => {
  try {
    const { id } = req.params;
    const character = findCharacterById(id);
    if (!character) {
      return res.status(404).json({ error: "Character not found" });
    }
    res.json({ success: true, character });
  } catch (err) {
    next(err);
  }
});

// Update character sheet
router.put("/:id", (req, res, next) => {
  try {
    const { id } = req.params;
    const updates = req.body || {};
    const character = updateCharacter(id, updates);
    res.json({ success: true, character });
  } catch (err) {
    next(err);
  }
});

// Update HP (for HP calculator)
router.patch("/:id/hp", (req, res, next) => {
  try {
    const { id } = req.params;
    const { currentHp, tempHp } = req.body || {};
    const character = updateCharacterHp(id, {
      currentHp: typeof currentHp === "number" ? currentHp : undefined,
      tempHp: typeof tempHp === "number" ? tempHp : undefined
    });
    res.json({ success: true, character });
  } catch (err) {
    next(err);
  }
});

// Add item to character inventory (DM loot transfer)
router.post("/:id/items", (req, res, next) => {
  try {
    const { id } = req.params;
    const item = req.body || {};
    const character = addItemToCharacter(id, item);
    res.json({ success: true, character });
  } catch (err) {
    next(err);
  }
});

export default router;
