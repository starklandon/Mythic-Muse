import express from "express";
import { authenticate } from "../utils/authMiddleware.js";
import {
  createSession,
  getSessionsForUser,
  findSessionByInviteKey,
  joinSession
} from "../models/sessionStore.js";

const router = express.Router();

router.use(authenticate);

// Create a new session (campaign)
router.post("/", (req, res, next) => {
  try {
    const { name } = req.body || {};
    if (!name) {
      return res.status(400).json({ error: "Session name is required" });
    }

    const session = createSession({ name, dmId: req.user.id });
    res.json({ success: true, session });
  } catch (err) {
    next(err);
  }
});

// Get sessions for current user
router.get("/", (req, res, next) => {
  try {
    const sessions = getSessionsForUser(req.user.id);
    res.json({ success: true, sessions });
  } catch (err) {
    next(err);
  }
});

// Join a session by invite key
router.post("/join", (req, res, next) => {
  try {
    const { inviteKey } = req.body || {};
    if (!inviteKey) {
      return res.status(400).json({ error: "Invite key is required" });
    }

    const session = findSessionByInviteKey(inviteKey);
    if (!session) {
      return res.status(404).json({ error: "Session not found" });
    }

    const updated = joinSession({ sessionId: session.id, userId: req.user.id });
    res.json({ success: true, session: updated });
  } catch (err) {
    next(err);
  }
});

export default router;
