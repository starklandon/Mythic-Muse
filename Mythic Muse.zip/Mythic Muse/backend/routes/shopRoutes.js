import express from "express";
import { generateShopInventory } from "../utils/openaiHelpers.js";

const router = express.Router();

router.post("/generate", async (req, res, next) => {
  try {
    const { tier, goldBudget, itemTypes, theme } = req.body || {};

    const shop = await generateShopInventory({
      tier,
      goldBudget,
      itemTypes,
      theme
    });

    res.json({
      success: true,
      shop
    });
  } catch (err) {
    next(err);
  }
});

export default router;
