export function cleanJSON(text) {
  if (!text || typeof text !== "string") return text;

  return text
    .replace(/^```json\s*/i, "")
    .replace(/^```\s*/i, "")
    .replace(/```$/i, "")
    .trim();
}

export function safeJSONParse(str) {
  try {
    return JSON.parse(str);
  } catch {
    return null;
  }
}
