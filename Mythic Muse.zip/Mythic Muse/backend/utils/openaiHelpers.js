import client, { getTextModel } from "../config/openaiClient.js";
import { cleanJSON, safeJSONParse } from "./jsonUtils.js";
import { normalizeCreature } from "../schemas/creatureSchema.js";
import { normalizeItem } from "../schemas/itemSchema.js";
import { normalizeEncounter } from "../schemas/encounterSchema.js";
import { normalizeShop } from "../schemas/shopSchema.js";
import { normalizeLoot } from "../schemas/lootSchema.js";

/* =======================================================
   CORE JSON COMPLETION
   ======================================================= */
async function createJSONCompletion(systemPrompt, userPrompt) {
  const model = getTextModel();

  const response = await client.chat.completions.create({
    model,
    response_format: { type: "json_object" },
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: userPrompt }
    ],
    temperature: 0.8
  });

  const raw = response.choices[0]?.message?.content || "{}";
  const cleaned = cleanJSON(raw);
  const parsed = safeJSONParse(cleaned);

  if (!parsed || typeof parsed !== "object") {
    const error = new Error("Failed to parse JSON from OpenAI response");
    error.raw = raw;
    throw error;
  }

  return parsed;
}

/* =======================================================
   CREATURE GENERATION
   ======================================================= */
export async function generateCreature({ cr, archetype, flavor }) {
  const systemPrompt = `
     Always respond in strict JSON format.
     You are a professional D&D 5e homebrew monster designer.

     All mechanics must:
     - Follow 5e balance
     - Match the requested CR
     - Be original
     - Use clear rules text

     REQUIRED STATBLOCK SHAPE:
     {
       "name": string,
       "cr": number | string,
       "size": string,
       "type": string,
       "alignment": string,
       "armorClass": number,
       "hitPoints": { "average": number, "formula": string },
       "speed": {
         "walk": string,
         "fly": string | null,
         "swim": string | null,
         "climb": string | null,
         "burrow": string | null
       },
       "abilities": {
         "str": number,
         "dex": number,
         "con": number,
         "int": number,
         "wis": number,
         "cha": number
       },
       "savingThrows": { "[ability]": number },
       "skills": { "[skill]": number },
       "senses": string[],
       "languages": string[],
       "traits": [
         { "name": string, "description": string }
       ],
       "actions": [
         {
           "name": string,
           "type": "Melee Weapon Attack" | "Ranged Weapon Attack" | "Spell" | "Ability",
           "description": string,
           "attackBonus": number | null,
           "damage": string | null,
           "saveDC": number | null
         }
       ],
       "reactions": [
         { "name": string, "description": string }
       ],
       "legendaryActions": [
         { "name": string, "description": string }
       ],
       "environmentTags": string[]
     }
  `;

  const userPrompt = `
    Create a D&D 5e homebrew monster.

    Desired CR: ${cr ?? "any"}
    Archetype: ${archetype || "any"}
    Extra flavor: ${flavor || "none"}
  `;

  const json = await createJSONCompletion(systemPrompt, userPrompt);
  return normalizeCreature(json);
}

/* =======================================================
   ITEM GENERATION
   ======================================================= */
export async function generateItem({ rarity, slot, theme }) {
  const systemPrompt = `
    Always respond in strict JSON format.
    You are a D&D 5e professional magic item creator.

    When generating weapons:
    - ALWAYS choose a specific 5e weapon (Dagger, Longsword, Chain Mail, etc.).
    - Use the correct base damage dice for that weapon.

    REQUIRED JSON STRUCTURE:
    {
      "name": string,
      "type": string,          // specific weapon/armor/item type
      "rarity": string,
      "attunement": boolean,
      "slot": string | null,

      "baseDamage": {
        "dice": string,
        "type": string
      } | null,
      "magicalDamage": string | null,

      "armorClass": number | null,
      "armorCategory": "light" | "medium" | "heavy" | "shield" | null,
      "requiresStrength": boolean,
      "strengthRequirement": number | null,
      "stealthDisadvantage": boolean,

      "description": string,
      "mechanicalEffects": string[],
      "spellEffects": string | null,
      "tags": string[],

      "value": {
        "gp": number,
        "notes": string
      },
      "charges": number | null,
      "consumable": boolean,
      "stackable": boolean
    }

    ARMOR RULES (MANDATORY):
    - ALL armor items MUST include a correct armorClass value.
    - Use official 5e base AC:
        Light Armor:
          Padded 11 + Dex
          Leather 11 + Dex
          Studded Leather 12 + Dex
        Medium Armor:
          Hide 12 + Dex(max 2)
          Chain Shirt 13 + Dex(max 2)
          Scale Mail 14 + Dex(max 2)
          Breastplate 14 + Dex(max 2)
          Half Plate 15 + Dex(max 2)
        Heavy Armor:
          Ring Mail 14
          Chain Mail 16
          Splint 17
          Plate 18
        Shields:
          +2 AC
    - Mithral or magical variants MUST STILL include armorClass.
    - Non-armor items MUST set armorClass = null and armorCategory = null,
      requiresStrength = false, strengthRequirement = null,
      stealthDisadvantage = false.
  `;

  const userPrompt = `
    Generate a magic item.

    Rarity: ${rarity || "uncommon"}
    Preferred slot: ${slot || "any"}
    Theme: ${theme || "none"}
  `;

  const json = await createJSONCompletion(systemPrompt, userPrompt);
  return normalizeItem(json);
}

/* =======================================================
   ENCOUNTER GENERATION
   ======================================================= */
export async function generateEncounter({
  partyLevel,
  partySize,
  difficulty,
  biome,
  theme
}) {
  const systemPrompt = `
    Always respond in strict JSON format.
    You are a 5e encounter designer.

    REQUIRED FIELDS:
    - "name": string
    - "theme": string | null
    - "environment": string
    - "difficulty": "easy" | "medium" | "hard" | "deadly"
    - "party": { "level": number, "size": number }

    - "creatures": [
        FULL statblocks, each containing:
        {
          "name": string,
          "count": number,
          "role": string | null,
          "cr": number | string,
          "size": string,
          "type": string,
          "alignment": string,
          "armorClass": number,
          "hitPoints": { "average": number, "formula": string },
          "speed": {
            "walk": string,
            "fly": string | null,
            "swim": string | null,
            "climb": string | null,
            "burrow": string | null
          },
          "abilities": {
            "str": number,
            "dex": number,
            "con": number,
            "int": number,
            "wis": number,
            "cha": number
          },
          "savingThrows": { "[ability]": number },
          "skills":        { "[skill]": number },
          "senses":        string[],
          "languages":     string[],
          "traits": [
            { "name": string, "description": string }
          ],
          "actions": [
            {
              "name": string,
              "type": "Melee Weapon Attack" | "Ranged Weapon Attack" | "Spell" | "Ability",
              "description": string,
              "attackBonus": number | null,
              "damage": string | null,
              "saveDC": number | null
            }
          ],
          "reactions": [
            { "name": string, "description": string }
          ],
          "legendaryActions": [
            { "name": string, "description": string }
          ]
        }
      ]

    - "tactics": string
    - "treasure": string[]
    - "notes": string | null
  `;

  const userPrompt = `
    Create a balanced, original D&D 5e encounter.

    Party level: ${partyLevel}
    Party size: ${partySize}
    Difficulty: ${difficulty}
    Environment: ${biome}
    Theme: ${theme || "none"}
  `;

  const json = await createJSONCompletion(systemPrompt, userPrompt);
  return normalizeEncounter(json);
}

/* =======================================================
   SHOP GENERATION — PATCHED FOR ARMOR AC
   ======================================================= */
export async function generateShopInventory({
  tier,
  goldBudget,
  itemTypes,
  theme
}) {
  const systemPrompt = `
    Always respond in strict JSON format.
    You are a D&D 5e magic shop generator.

    REQUIRED ITEM SCHEMA:
    {
      "name": string,
      "type": string,
      "rarity": string,
      "attunement": boolean,
      "slot": string | null,

      "baseDamage": {
        "dice": string,
        "type": string
      } | null,
      "magicalDamage": string | null,

      "armorClass": number | null,
      "armorCategory": "light" | "medium" | "heavy" | "shield" | null,
      "requiresStrength": boolean,
      "strengthRequirement": number | null,
      "stealthDisadvantage": boolean,

      "spellEffects": string | null,
      "mechanicalEffects": string[],
      "tags": string[],

      "description": string,
      "consumable": boolean,
      "stackable": boolean,

      "value": {
        "gp": number,
        "notes": string
      },
      "price": number
    }

    ARMOR RULES (MANDATORY):
    - ALL armor items MUST specify armorClass.
    - Use official 5e base AC (light/medium/heavy/shield).
    - Mithral or other special materials MUST still include armorClass.
    - Non-armor: armorClass = null, armorCategory = null,
      requiresStrength = false, strengthRequirement = null,
      stealthDisadvantage = false.

    OTHER RULES:
    - mechanicalEffects & tags MUST always be arrays.
    - All fields must be present.
    - Prices must be roughly appropriate for rarity and tier.
  `;

  const userPrompt = `
    Generate a 5e magic shop.

    Tier: ${tier || "mid"}
    Gold budget: ${goldBudget || 1000}
    Item types: ${itemTypes || "mixed"}
    Theme: ${theme || "none"}

    Return ONLY valid JSON in the described schema.
  `;

  const json = await createJSONCompletion(systemPrompt, userPrompt);

  // SAFEGUARD: repair arrays & ensure armor defaults exist
  if (json.items && Array.isArray(json.items)) {
    json.items = json.items.map((it) => {
      const fixed = {
        ...it,
        mechanicalEffects: Array.isArray(it.mechanicalEffects)
          ? it.mechanicalEffects
          : [],
        tags: Array.isArray(it.tags) ? it.tags : []
      };

      // If it looks like armor, ensure armor fields are set
      if (
        fixed.tags.includes("armor") ||
        ["light", "medium", "heavy", "shield"].some((cat) =>
          fixed.tags.includes(cat)
        )
      ) {
        if (fixed.armorClass == null) {
          // Fallback if the model still forgets
          fixed.armorClass = 13;
        }
        if (!fixed.armorCategory) fixed.armorCategory = "medium";
        if (fixed.requiresStrength == null) fixed.requiresStrength = false;
        if (fixed.strengthRequirement == null) fixed.strengthRequirement = null;
        if (fixed.stealthDisadvantage == null)
          fixed.stealthDisadvantage = false;
      }

      return fixed;
    });
  }

  return normalizeShop(json);
}

/* =======================================================
   LEVEL-UP ADVICE
   ======================================================= */
export async function generateLevelupAdvice({
  currentLevel,
  characterClass,
  subclass,
  partyRole,
  preferences
}) {
  const systemPrompt = `
     Always respond in strict JSON format.
     You are a D&D 5e character optimization coach.

     REQUIRED STRUCTURE:
     {
       "summary": string,
       "recommendedFeatures": string[],
       "recommendedSpells": string[],
       "recommendedFeats": string[],
       "playstyleTips": string[]
     }
  `;

  const userPrompt = `
    Provide level-up advice for a D&D 5e character.

    Current level: ${currentLevel || "unknown"}
    Class: ${characterClass || "unknown"}
    Subclass: ${subclass || "unknown"}
    Party role: ${partyRole || "mixed"}
    Player preferences: ${preferences || "none"}
  `;

  const json = await createJSONCompletion(systemPrompt, userPrompt);
  return json;
}

/* =======================================================
   LOOT GENERATION — PATCHED TO MATCH SHOP
   ======================================================= */
export async function generateLoot({ goldBudget, theme }) {
  const systemPrompt = `
    Always respond in strict JSON format.

    You are a D&D 5e loot generator for post-combat rewards and treasure containers.

    REQUIRED OUTPUT:
    {
      "goldBudget": number,
      "summary": string | null,
      "estimatedValue": {
        "gp": number,
        "notes": string
      },
      "items": [
        {
          "name": string,
          "type": string,
          "rarity": string,
          "attunement": boolean,
          "slot": string | null,

          "baseDamage": {
            "dice": string,
            "type": string
          } | null,
          "magicalDamage": string | null,

          "armorClass": number | null,
          "armorCategory": "light" | "medium" | "heavy" | "shield" | null,
          "requiresStrength": boolean,
          "strengthRequirement": number | null,
          "stealthDisadvantage": boolean,

          "description": string,
          "mechanicalEffects": string[],
          "spellEffects": string | null,
          "tags": string[],
          "value": {
            "gp": number,
            "notes": string
          },

          "charges": number | null,
          "consumable": boolean,
          "stackable": boolean
        }
      ]
    }

    RULES:
    - items[] must contain 3–5 entries.
    - Mix: trash/junk, coins/gems, trinkets, potions, possibly a simple magic item.
    - Total estimatedValue.gp should be near goldBudget.
    - Non-armor items MUST set armorClass=null, armorCategory=null,
      requiresStrength=false, strengthRequirement=null, stealthDisadvantage=false.
    - All arrays MUST exist.
  `;

  const userPrompt = `
    Generate a random loot bundle for a D&D 5e encounter.

    Approximate gold budget: ${goldBudget ?? 0} gp
    Theme or context: ${theme || "generic fantasy dungeon"}
  `;

  const json = await createJSONCompletion(systemPrompt, userPrompt);

  // SAFETY PATCH: mirror shop behavior
  if (json.items && Array.isArray(json.items)) {
    json.items = json.items.map((it) => {
      const fixed = {
        ...it,
        mechanicalEffects: Array.isArray(it.mechanicalEffects)
          ? it.mechanicalEffects
          : [],
        tags: Array.isArray(it.tags) ? it.tags : []
      };

      if (
        fixed.tags.includes("armor") ||
        ["light", "medium", "heavy", "shield"].some((cat) =>
          fixed.tags.includes(cat)
        )
      ) {
        if (fixed.armorClass == null) fixed.armorClass = 13;
        if (!fixed.armorCategory) fixed.armorCategory = "medium";
        if (fixed.requiresStrength == null) fixed.requiresStrength = false;
        if (fixed.strengthRequirement == null) fixed.strengthRequirement = null;
        if (fixed.stealthDisadvantage == null)
          fixed.stealthDisadvantage = false;
      }

      return fixed;
    });
  }

  return normalizeLoot(json);
}
