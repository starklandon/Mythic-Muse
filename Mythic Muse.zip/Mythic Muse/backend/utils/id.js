export function generateId(prefix = "") {
  const random = Math.random().toString(36).slice(2, 10);
  const time = Date.now().toString(36);
  return prefix ? `${prefix}_${time}_${random}` : `${time}_${random}`;
}

export function generateInviteKey() {
  // Simple 8-character invite key (A-Z0-9)
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let key = "";
  for (let i = 0; i < 8; i++) {
    key += chars[Math.floor(Math.random() * chars.length)];
  }
  return key;
}
