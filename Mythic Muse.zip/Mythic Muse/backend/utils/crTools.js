// Map of common fractional CR values to decimals
const FRACTION_MAP = {
  "0": 0,
  "1/8": 0.125,
  "1/6": 1 / 6,
  "1/4": 0.25,
  "1/3": 1 / 3,
  "1/2": 0.5,
  "2/3": 2 / 3,
  "3/4": 0.75
};

/**
 * Normalize a CR input into a decimal number.
 * Accepts:
 *  - numbers (0.125, 0.5, 2, etc)
 *  - strings like "1/4", "1/2", "2", " 1 / 8 "
 */
export function normalizeCR(input) {
  if (input === null || input === undefined) return 0;

  if (typeof input === "number" && !Number.isNaN(input)) {
    return input;
  }

  if (typeof input === "string") {
    let value = input.trim().toLowerCase();

    // map common simple fractions
    if (FRACTION_MAP[value] !== undefined) {
      return FRACTION_MAP[value];
    }

    // generic fraction "a/b"
    if (value.includes("/")) {
      const [numStr, denStr] = value.split("/").map((s) => s.trim());
      const num = Number(numStr);
      const den = Number(denStr);
      if (!Number.isNaN(num) && !Number.isNaN(den) && den !== 0) {
        return num / den;
      }
    }

    const asNum = Number(value);
    if (!Number.isNaN(asNum)) {
      return asNum;
    }
  }

  return 0;
}

/**
 * Optional helper to convert decimal CR back to a string for display.
 * We only handle the standard 5e fractions and integers.
 */
export function crToDisplay(cr) {
  const n = Number(cr);
  if (!Number.isFinite(n)) return "0";

  const entries = Object.entries(FRACTION_MAP);
  for (const [key, val] of entries) {
    if (Math.abs(val - n) < 1e-6) return key;
  }

  if (Number.isInteger(n)) return String(n);
  return n.toFixed(2);
}
