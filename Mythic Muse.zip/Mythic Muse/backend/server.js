import express from "express";
import cors from "cors";
import dotenv from "dotenv";

import authRoutes from "./routes/authRoutes.js";
import sessionRoutes from "./routes/sessionRoutes.js";
import characterRoutes from "./routes/characterRoutes.js";
import creatureRoutes from "./routes/creatureRoutes.js";
import itemRoutes from "./routes/itemRoutes.js";
import encounterRoutes from "./routes/encounterRoutes.js";
import shopRoutes from "./routes/shopRoutes.js";
import levelupRoutes from "./routes/levelupRoutes.js";
import lootRoutes from "./routes/lootRoutes.js";
import playerInventoryRoutes from "./routes/playerInventoryRoutes.js";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;
const FRONTEND_URL = process.env.FRONTEND_URL || "*";

app.use(
  cors({
    origin: FRONTEND_URL,
    credentials: true
  })
);

app.use(express.json({ limit: "2mb" }));

// Health check
app.get("/", (req, res) => {
  res.json({
    status: "ok",
    message: "D&D AI Assistant backend running"
  });
});

// Basic test endpoints for easier debugging (no OpenAI)
app.get("/api/test/creature", (req, res) => {
  res.json({ success: true, test: "creature endpoint reachable" });
});

app.get("/api/test/encounter", (req, res) => {
  res.json({ success: true, test: "encounter endpoint reachable" });
});

// Core routes
app.use("/api/auth", authRoutes);
app.use("/api/sessions", sessionRoutes);
app.use("/api/characters", characterRoutes);
app.use("/api/creatures", creatureRoutes);
app.use("/api/items", itemRoutes);
app.use("/api/encounters", encounterRoutes);
app.use("/api/shops", shopRoutes);
app.use("/api/levelup", levelupRoutes);
app.use("/api/loot", lootRoutes);
app.use("/api/player-inventory", playerInventoryRoutes);

// 404 handler
app.use((req, res, next) => {
  res.status(404).json({
    error: "Not Found",
    path: req.originalUrl
  });
});

// Central error handler
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error("❌ API Error:", err);

  const status = err.status || 500;
  res.status(status).json({
    error: err.message || "Internal Server Error",
    ...(process.env.NODE_ENV === "development" && { stack: err.stack })
  });
});

app.listen(PORT, () => {
  console.log(`✅ D&D AI Assistant backend listening on port ${PORT}`);
});
