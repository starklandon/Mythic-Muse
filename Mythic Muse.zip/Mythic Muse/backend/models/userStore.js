import { generateId } from "../utils/id.js";

const users = [];

/**
 * Simple in-memory user store.
 * In production, replace this with a real database.
 */

export function createUser({ email, passwordHash }) {
  const existing = users.find((u) => u.email.toLowerCase() === email.toLowerCase());
  if (existing) {
    const err = new Error("Email already registered");
    err.status = 400;
    throw err;
  }

  const user = {
    id: generateId("user"),
    email,
    passwordHash
  };
  users.push(user);
  return user;
}

export function findUserByEmail(email) {
  return users.find((u) => u.email.toLowerCase() === email.toLowerCase()) || null;
}

export function findUserById(id) {
  return users.find((u) => u.id === id) || null;
}
