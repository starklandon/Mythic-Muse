import { generateId } from "../utils/id.js";
import { normalizeItem } from "../schemas/itemSchema.js";

const playerInventory = [];

/**
 * Simple in-memory player inventory.
 * This is intentionally lightweight and not tied to authentication yet.
 */

export function getPlayerInventory() {
  return playerInventory;
}

export function addItemToPlayerInventory(rawItem = {}) {
  const item = normalizeItem(rawItem);

  const entry = {
    id: generateId("inv_"),
    ...item
  };

  playerInventory.push(entry);
  return entry;
}

export function clearPlayerInventory() {
  playerInventory.length = 0;
}
