import { generateId, generateInviteKey } from "../utils/id.js";

const sessions = [];

/**
 * In-memory session/campaign store.
 */

export function createSession({ name, dmId }) {
  const session = {
    id: generateId("session"),
    name,
    dmId,
    inviteKey: generateInviteKey(),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    playerIds: []
  };
  sessions.push(session);
  return session;
}

export function getSessionsForUser(userId) {
  return sessions.filter((s) => s.dmId === userId || s.playerIds.includes(userId));
}

export function findSessionByInviteKey(inviteKey) {
  return sessions.find((s) => s.inviteKey === inviteKey) || null;
}

export function joinSession({ sessionId, userId }) {
  const session = sessions.find((s) => s.id === sessionId);
  if (!session) {
    const err = new Error("Session not found");
    err.status = 404;
    throw err;
  }
  if (!session.playerIds.includes(userId) && session.dmId !== userId) {
    session.playerIds.push(userId);
    session.updatedAt = new Date().toISOString();
  }
  return session;
}
