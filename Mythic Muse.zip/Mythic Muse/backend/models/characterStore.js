import { generateId } from "../utils/id.js";

const characters = [];

/**
 * In-memory character storage tied to sessions and users.
 */

export function createCharacter({
  userId,
  sessionId,
  name,
  race,
  charClass,
  subclass,
  level
}) {
  const character = {
    id: generateId("char"),
    userId,
    sessionId,
    name: name || "Unnamed Hero",
    race: race || "Human",
    class: charClass || "Fighter",
    subclass: subclass || null,
    level: level || 1,
    abilityScores: {
      str: 10,
      dex: 10,
      con: 10,
      int: 10,
      wis: 10,
      cha: 10
    },
    maxHp: 10,
    currentHp: 10,
    tempHp: 0,
    armorClass: 10,
    speed: 30,
    proficiencyBonus: 2,
    spellcasting: {
      spellcastingClass: null,
      spellSlots: {},
      knownSpells: [],
      preparedSpells: []
    },
    inventory: [], // { id, name, type, description, quantity }
    notes: ""
  };

  characters.push(character);
  return character;
}

export function getCharactersForSession(sessionId) {
  return characters.filter((c) => c.sessionId === sessionId);
}

export function getCharactersForUser(userId) {
  return characters.filter((c) => c.userId === userId);
}

export function findCharacterById(id) {
  return characters.find((c) => c.id === id) || null;
}

export function updateCharacter(id, updates) {
  const char = characters.find((c) => c.id === id);
  if (!char) {
    const err = new Error("Character not found");
    err.status = 404;
    throw err;
  }
  Object.assign(char, updates, { id: char.id });
  return char;
}

export function updateCharacterHp(id, { currentHp, tempHp }) {
  const char = characters.find((c) => c.id === id);
  if (!char) {
    const err = new Error("Character not found");
    err.status = 404;
    throw err;
  }
  if (typeof currentHp === "number") {
    char.currentHp = Math.max(0, Math.min(currentHp, char.maxHp));
  }
  if (typeof tempHp === "number") {
    char.tempHp = Math.max(0, tempHp);
  }
  return char;
}

export function addItemToCharacter(id, item) {
  const char = characters.find((c) => c.id === id);
  if (!char) {
    const err = new Error("Character not found");
    err.status = 404;
    throw err;
  }

  const existing = char.inventory.find((inv) => inv.name === item.name);
  if (existing && item.stackable) {
    existing.quantity += item.quantity || 1;
  } else {
    char.inventory.push({
      ...item,
      quantity: item.quantity || 1
    });
  }
  return char;
}
