import dotenv from "dotenv";
import OpenAI from "openai";

dotenv.config();

if (!process.env.OPENAI_API_KEY) {
  console.warn("[WARN] OPENAI_API_KEY is not set. AI endpoints will fail until it is configured.");
}

const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

export function getTextModel() {
  return process.env.OPENAI_MODEL_TEXT || "gpt-4.1";
}

export function getImageModel() {
  return process.env.OPENAI_MODEL_IMAGE || "gpt-image-1";
}

export default client;
