import React from "react";

interface TomeLayoutProps {
  children: React.ReactNode;
  rightHeader?: React.ReactNode;
}

export const TomeLayout: React.FC<TomeLayoutProps> = ({
  children,
  rightHeader
}) => {
  return (
    <div className="app-shell">
      <div className="app-inner">
        <header className="app-header">
          <div className="app-title">
            <span className="sigils" aria-hidden="true">
              <span>★</span>
              <span>✧</span>
              <span>✦</span>
            </span>
            Tomeforge Assistant
          </div>
          <div className="app-header-right">{rightHeader}</div>
        </header>
        <div className="book-body">{children}</div>
      </div>
    </div>
  );
};
