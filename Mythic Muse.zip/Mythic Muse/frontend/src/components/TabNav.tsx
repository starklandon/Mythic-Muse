import React from "react";
import { useLocation, useNavigate } from "react-router-dom";

interface TabDef {
  path: string;
  label: string;
  icon: string;
}

const dmTabs: TabDef[] = [
  { path: "/dm/creatures", label: "Creatures", icon: "🐉" },
  { path: "/dm/items", label: "Magic Items", icon: "🗡️" },
  { path: "/dm/encounters", label: "Encounters", icon: "⚔️" },
  { path: "/dm/shops", label: "Shops", icon: "🏪" },
  { path: "/dm/loot", label: "Loot", icon: "💰" },
];

const playerTabs: TabDef[] = [
  { path: "/player/character", label: "Character", icon: "🧙" },
  { path: "/player/inventory", label: "Inventory", icon: "🎒" },
  { path: "/player/spellbook", label: "Spellbook", icon: "📜" },
  { path: "/player/levelup", label: "Level Up", icon: "⬆️" }
];

interface TabNavProps {
  mode: "dm" | "player";
}

export const TabNav: React.FC<TabNavProps> = ({ mode }) => {
  const location = useLocation();
  const navigate = useNavigate();

  const tabs = mode === "dm" ? dmTabs : playerTabs;

  return (
    <div className="tab-row">
      {tabs.map((tab) => {
        const active = location.pathname.startsWith(tab.path);
        return (
          <button
            key={tab.path}
            type="button"
            className={`tab-chip ${active ? "active" : ""}`}
            onClick={() => navigate(tab.path)}
          >
            <span className="tab-icon" aria-hidden="true">
              {tab.icon}
            </span>
            {tab.label}
          </button>
        );
      })}
    </div>
  );
};
