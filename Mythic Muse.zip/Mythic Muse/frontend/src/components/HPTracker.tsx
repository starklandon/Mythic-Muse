
import React from "react";

interface HPTrackerChange {
  currentHp?: number;
  tempHp?: number;
}

interface HPTrackerProps {
  currentHp: number;
  maxHp: number;
  tempHp?: number;
  onChange: (values: HPTrackerChange) => void;
}

export const HPTracker: React.FC<HPTrackerProps> = ({
  currentHp,
  maxHp,
  tempHp,
  onChange
}) => {
  const clamp = (value: number) => Math.max(0, Math.min(maxHp, value));
  const quickButtons = [-10, -5, -1, +1, +5, +10];

  const handleInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const num = Number(e.target.value);
    onChange({ currentHp: clamp(isNaN(num) ? 0 : num) });
  };

  const handleDelta = (d:number)=> onChange({ currentHp: clamp(currentHp + d) });

  return (
    <div style={{display:"flex",flexDirection:"column",gap:"0.35rem"}}>
      <div style={{display:"flex",alignItems:"center",gap:"0.35rem"}}>
        <span style={{fontWeight:600}}>HP</span>
        <input
          type="number"
          value={currentHp}
          onChange={handleInput}
          style={{width:"4rem",padding:"4px",borderRadius:"4px",
          border:"1px solid rgba(0,0,0,0.2)"}}
        />
        <span>/ {maxHp}</span>
        {tempHp? <span>(+{tempHp} temp)</span>:null}
      </div>

      <div style={{display:"flex",gap:"0.35rem",flexWrap:"wrap"}}>
        {quickButtons.map(b=>(
          <button key={b} type="button" className="btn btn-small"
            onClick={()=>handleDelta(b)}>
            {b>0?`+${b}`:b}
          </button>
        ))}
      </div>
    </div>
  );
};
