import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

const AuthLogin: React.FC = () => {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      await login(email, password);
      navigate("/sessions");
    } catch (err: any) {
      setError(err?.response?.data?.error || "Login failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="book-page">
      <div className="page-header">
        <div>
          <div className="page-title">Sign In</div>
          <div className="page-subtitle">
            Enter your credentials to access your sessions & characters.
          </div>
        </div>
      </div>
      <div className="auth-wrapper">
        <form className="card" onSubmit={handleSubmit}>
          <div className="card-header">
            <div className="card-title">Adventurer Registry</div>
          </div>
          <div className="field">
            <label htmlFor="email">Email</label>
            <input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <div className="field">
            <label htmlFor="password">Password</label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          {error && (
            <div style={{ color: "#b0423a", fontSize: "0.8rem" }}>{error}</div>
          )}
          <div className="auth-actions">
            <button
              className="btn btn-primary"
              type="submit"
              disabled={loading}
            >
              {loading ? "Signing in..." : "Sign In"}
            </button>
          </div>
          <div style={{ fontSize: "0.8rem", marginTop: "0.5rem" }}>
            New here?{" "}
            <Link to="/register" style={{ color: "#b0423a" }}>
              Create an account
            </Link>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AuthLogin;
