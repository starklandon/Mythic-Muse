
import React, { useState } from "react";
import { api } from "../api/client";
import type { Loot } from "../api/types";

const DMLootPage: React.FC = () => {
  const [goldBudget,setGoldBudget]=useState(100);
  const [theme,setTheme]=useState("");
  const [loot,setLoot]=useState<Loot|null>(null);
  const [loading,setLoading]=useState(false);
  const [error,setError]=useState<string|null>(null);

  const generateLoot=async(e:React.FormEvent)=>{
    e.preventDefault();
    setLoading(true); setError(null);
    try{
      const res=await api.post("/api/loot/generate",{goldBudget,theme});
      setLoot(res.data.loot);
    }catch(err:any){
      console.error(err);
      setError("Failed to generate loot.");
    }
    setLoading(false);
  };

  return (
    <div className="page-container">
      <h2>Loot Generator</h2>

      <form onSubmit={generateLoot} className="input-panel">
        <label>Gold Budget</label>
        <input type="number" value={goldBudget} 
          onChange={(e)=>setGoldBudget(Number(e.target.value))}/>

        <label>Theme (optional)</label>
        <input value={theme} onChange={(e)=>setTheme(e.target.value)}/>

        <button className="btn btn-primary" disabled={loading}>
          {loading? "Generating..." : "Generate Loot"}
        </button>
      </form>

      {error && <div className="error-text">{error}</div>}

      {loot && (
        <div className="output-panel">
          <h3>Loot Results</h3>
          <div className="stat-line">
            <span className="stat-label">Estimated Value</span>
            <span>{loot.estimatedValue.gp} gp</span>
          </div>

          {loot.items.map((item,i)=>(
            <div key={i} className="stat-block">
              <h4>{item.name}</h4>
              <div>{item.description}</div>

              {(item.mechanicalEffects?.length>0) && (
                <ul>
                  {item.mechanicalEffects.map(m=><li key={m}>{m}</li>)}
                </ul>
              )}

              {/* ARMOR */}
              {item.armorClass !== null && item.armorClass !== undefined !== null && (
                <div className="stat-line">
                  <span className="stat-label">Armor</span>
                  <span>
                    AC {item.armorClass}
                    {item.armorCategory ? ` (${item.armorCategory})` : ""}
                    {item.requiresStrength && item.strengthRequirement
                      ? ` · STR ${item.strengthRequirement}`
                      : ""}
                    {item.stealthDisadvantage ? " · Stealth Disadvantage" : ""}
                  </span>
                </div>
              )}

              <div className="stat-line">
                <span className="stat-label">Value</span>
                <span>
                  {item.value?.gp ?? "—"} gp
                </span>
              </div>

            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default DMLootPage;
