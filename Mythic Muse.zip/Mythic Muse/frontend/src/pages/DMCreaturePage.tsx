import React, { useState } from "react";
import { api } from "../api/client";
import type { Creature } from "../api/types";
import { HPTracker } from "../components/HPTracker";

const abilityMod = (score: number): string => {
  const mod = Math.floor((score - 10) / 2);
  return mod >= 0 ? `+${mod}` : `${mod}`;
};

const crOptions = [
  "0","1/8","1/4","1/2","1","2","3","4","5",
  "6","7","8","9","10","11","12","13","14","15",
  "16","17","18","19","20"
];

const DMCreaturePage: React.FC = () => {
  const [cr, setCr] = useState("3");
  const [archetype, setArchetype] = useState("undead");
  const [flavor, setFlavor] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [creature, setCreature] = useState<Creature | null>(null);

  // Local HP state used ONLY for UI
  const [hpState, setHpState] = useState({
    currentHp: 0,
    tempHp: 0
  });

  const generateCreature = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const res = await api.post("/api/creatures/generate", {
        cr,
        archetype,
        flavor
      });

      const c = res.data.creature;

      setCreature(c);

      // Initialize UI HP state
      setHpState({
        currentHp: c.hitPoints?.average ?? 1,
        tempHp: 0
      });

    } catch (err: any) {
      setError(err?.response?.data?.error || "Failed to generate creature");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="book-page">
      <div className="page-header">
        <div>
          <div className="page-title">Creature Generator</div>
          <div className="page-subtitle">
            Forge balanced 5e monsters ready for tonight's session.
          </div>
        </div>
      </div>

      <div className="page-body">

        {/* FORM */}
        <form className="card" onSubmit={generateCreature}>
          <div className="card-header">
            <div className="card-title">Parameters</div>
          </div>

          <div className="field-grid">
            <div className="field">
              <label>Challenge Rating</label>
              <select value={cr} onChange={(e) => setCr(e.target.value)}>
                {crOptions.map((o) => (
                  <option key={o} value={o}>{o}</option>
                ))}
              </select>
            </div>

            <div className="field">
              <label>Archetype</label>
              <select
                value={archetype}
                onChange={(e) => setArchetype(e.target.value)}
              >
                <option value="undead">Undead</option>
                <option value="fiend">Fiend</option>
                <option value="beast">Beast</option>
                <option value="dragon">Dragon</option>
                <option value="construct">Construct</option>
                <option value="fey">Fey</option>
                <option value="aberration">Aberration</option>
                <option value="humanoid">Humanoid</option>
              </select>
            </div>
          </div>

          <div className="field">
            <label>Flavor / Theme</label>
            <textarea
              value={flavor}
              onChange={(e) => setFlavor(e.target.value)}
            />
          </div>

          {error && (
            <div style={{ color: "#b0423a", fontSize: "0.8rem" }}>
              {error}
            </div>
          )}

          <div className="auth-actions">
            <button className="btn btn-primary" disabled={loading}>
              {loading ? "Summoning..." : "Generate Creature"}
            </button>
          </div>
        </form>

        {/* RESULT */}
        <div className="card">
          <div className="card-header">
            <div className="card-title">Result</div>
            {creature && (
              <span className="badge badge-gold">
                CR {creature.cr} · {creature.size} {creature.type}
              </span>
            )}
          </div>

          <div className="scroll-section">

            {!creature && (
              <div style={{ color: "#5b4a34", fontSize: "0.85rem" }}>
                Generate a creature to view its stat block.
              </div>
            )}

            {creature && (
              <div className="stat-block">
                <h3>{creature.name}</h3>

                {/* Armor Class & Hit Points */}
                <div className="stat-line">
                  <span className="stat-label">Armor Class</span>
                  <span>{creature.armorClass}</span>

                  <span className="stat-label">Hit Points</span>
                  <span>
                    {hpState.currentHp} / {creature.hitPoints.average}{" "}
                    ({creature.hitPoints.formula})
                  </span>
                </div>

                {/* Working HP Tracker */}
                <div style={{ marginTop: "0.6rem", marginBottom: "0.4rem" }}>
                  <HPTracker
                    currentHp={hpState.currentHp}
                    tempHp={hpState.tempHp}
                    maxHp={creature.hitPoints.average}
                    onChange={(vals) =>
                      setHpState((prev) => ({ ...prev, ...vals }))
                    }
                  />
                </div>

                {/* Abilities */}
                <div className="stat-line">
                  <span className="stat-label">Abilities</span>
                  <span>
                    STR {creature.abilities.str} ({abilityMod(creature.abilities.str)}) ·{" "}
                    DEX {creature.abilities.dex} ({abilityMod(creature.abilities.dex)}) ·{" "}
                    CON {creature.abilities.con} ({abilityMod(creature.abilities.con)}) ·{" "}
                    INT {creature.abilities.int} ({abilityMod(creature.abilities.int)}) ·{" "}
                    WIS {creature.abilities.wis} ({abilityMod(creature.abilities.wis)}) ·{" "}
                    CHA {creature.abilities.cha} ({abilityMod(creature.abilities.cha)})
                  </span>
                </div>

                {/* Traits */}
                {creature.traits.length > 0 && (
                  <div style={{ marginTop: "0.8rem" }}>
                    <div className="stat-label">Traits</div>
                    {creature.traits.map((t) => (
                      <div key={t.name}>
                        <strong>{t.name}.</strong> {t.description}
                      </div>
                    ))}
                  </div>
                )}

                {/* Actions */}
                {creature.actions.length > 0 && (
                  <div style={{ marginTop: "0.8rem" }}>
                    <div className="stat-label">Actions</div>
                    {creature.actions.map((a) => (
                      <div key={a.name}>
                        <strong>{a.name}.</strong> {a.description}
                      </div>
                    ))}
                  </div>
                )}

              </div>
            )}

          </div>
        </div>

      </div>
    </div>
  );
};

export default DMCreaturePage;
