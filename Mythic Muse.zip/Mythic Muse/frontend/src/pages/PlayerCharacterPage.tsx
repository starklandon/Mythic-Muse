import React, { useEffect, useState } from "react";
import { api } from "../api/client";
import type { Character } from "../api/types";
import { HPTracker } from "../components/HPTracker";

const PlayerCharacterPage: React.FC = () => {
  const [characters, setCharacters] = useState<Character[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const load = async () => {
      try {
        const res = await api.get("/api/characters/mine");
        const chars = (res.data.characters || []) as Character[];
        setCharacters(chars);
        if (chars.length > 0) {
          setSelectedId(chars[0].id);
        }
      } catch (err: any) {
        setError(err?.response?.data?.error || "Failed to load characters");
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  const current = characters.find((c) => c.id === selectedId) || null;

  const updateHp = async (values: { currentHp?: number; tempHp?: number }) => {
    if (!current) return;
    const newCurrentHp =
      values.currentHp !== undefined ? values.currentHp : current.currentHp;
    const newTempHp =
      values.tempHp !== undefined ? values.tempHp : current.tempHp;
    try {
      const res = await api.patch(`/api/characters/${current.id}/hp`, {
        currentHp: newCurrentHp,
        tempHp: newTempHp
      });
      const updated = res.data.character as Character;
      setCharacters((prev) =>
        prev.map((c) => (c.id === updated.id ? updated : c))
      );
    } catch (err: any) {
      console.error("Failed to update HP", err);
    }
  };

  return (
    <div className="book-page">
      <div className="page-header">
        <div>
          <div className="page-title">Character Sheet</div>
          <div className="page-subtitle">
            A single, living sheet for your 5e hero, with quick HP controls.
          </div>
        </div>
      </div>
      <div className="page-body">
        <div className="card">
          <div className="card-header">
            <div className="card-title">Your Characters</div>
          </div>
          {loading && <div>Loading...</div>}
          {error && (
            <div style={{ color: "#b0423a", fontSize: "0.8rem" }}>{error}</div>
          )}
          <div className="session-list">
            {characters.map((c) => (
              <button
                key={c.id}
                type="button"
                onClick={() => setSelectedId(c.id)}
                className="session-item"
                style={{
                  borderColor:
                    c.id === selectedId
                      ? "rgba(176,66,58,0.9)"
                      : "rgba(0,0,0,0.15)"
                }}
              >
                <div>
                  <div className="session-item-title">{c.name}</div>
                  <div className="session-item-meta">
                    {c.race} {c.class} · Level {c.level}
                  </div>
                </div>
              </button>
            ))}
            {!loading && characters.length === 0 && (
              <div style={{ fontSize: "0.85rem", color: "#5b4a34" }}>
                No characters yet. Use the future “Create Character” flow to add
                one.
              </div>
            )}
          </div>
        </div>
        <div className="card">
          <div className="card-header">
            <div className="card-title">Details</div>
          </div>
          <div className="scroll-section">
            {current ? (
              <div className="stat-block">
                <h3>
                  {current.name} — Lv {current.level} {current.race}{" "}
                  {current.class}
                </h3>
                <div className="stat-line" style={{ marginTop: "0.4rem" }}>
                  <span className="stat-label">Armor Class</span>
                  <span>{current.armorClass}</span>
                  <span className="stat-label">Speed</span>
                  <span>{current.speed} ft.</span>
                </div>
                <div style={{ marginTop: "0.6rem", marginBottom: "0.5rem" }}>
                  <HPTracker
                    currentHp={current.currentHp}
                    maxHp={current.maxHp}
                    tempHp={current.tempHp}
                    onChange={updateHp}
                  />
                </div>
                <div className="stat-line" style={{ marginTop: "0.4rem" }}>
                  <span className="stat-label">Abilities</span>
                  <span>
                    STR {current.abilityScores.str} · DEX{" "}
                    {current.abilityScores.dex} · CON{" "}
                    {current.abilityScores.con} · INT{" "}
                    {current.abilityScores.int} · WIS{" "}
                    {current.abilityScores.wis} · CHA{" "}
                    {current.abilityScores.cha}
                  </span>
                </div>
                {current.inventory.length > 0 && (
                  <div style={{ marginTop: "0.8rem" }}>
                    <div className="stat-label">Inventory</div>
                    <ul>
                      {current.inventory.map((i, idx) => (
                        <li key={`${i.name}-${idx}`}>
                          {i.quantity} × {i.name}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            ) : (
              <div
                style={{
                  fontSize: "0.85rem",
                  color: "#5b4a34"
                }}
              >
                Select a character on the left to view their sheet.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PlayerCharacterPage;
