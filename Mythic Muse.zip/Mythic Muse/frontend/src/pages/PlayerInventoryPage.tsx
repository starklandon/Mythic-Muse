import React from "react";

const PlayerInventoryPage: React.FC = () => {
  return (
    <div className="book-page">
      <div className="page-header">
        <div>
          <div className="page-title">Inventory</div>
          <div className="page-subtitle">
            View items granted by your DM and track your gear.
          </div>
        </div>
      </div>
      <div className="page-body">
        <div className="card" style={{ gridColumn: "1 / -1" }}>
          <div className="card-header">
            <div className="card-title">Coming Soon</div>
          </div>
          <div style={{ fontSize: "0.85rem", color: "#5b4a34" }}>
            In a future iteration, this page will show a full, interactive
            inventory synced with your character and any loot transferred by
            your DM. For now, inventory is visible inside the Character sheet.
          </div>
        </div>
      </div>
    </div>
  );
};

export default PlayerInventoryPage;
