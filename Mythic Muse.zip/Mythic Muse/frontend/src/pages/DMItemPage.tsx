import React, { useState } from "react";
import { api } from "../api/client";
import type { MagicItem } from "../api/types";

const DMItemPage: React.FC = () => {
  const [rarity, setRarity] = useState("uncommon");
  const [slot, setSlot] = useState("weapon");
  const [theme, setTheme] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [item, setItem] = useState<MagicItem | null>(null);

  const generateItem = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const res = await api.post("/api/items/generate", {
        rarity,
        slot,
        theme
      });
      setItem(res.data.item);
    } catch (err: any) {
      setError(err?.response?.data?.error || "Failed to generate item");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="book-page">
      <div className="page-header">
        <div>
          <div className="page-title">Magic Item Generator</div>
          <div className="page-subtitle">
            Conjure D&D-inspired homebrew gear with balanced mechanics and flavor.
          </div>
        </div>
      </div>
      <div className="page-body">
        <form className="card" onSubmit={generateItem}>
          <div className="card-header">
            <div className="card-title">Parameters</div>
          </div>
          <div className="field-grid">
            <div className="field">
              <label htmlFor="rarity">Rarity</label>
              <select
                id="rarity"
                value={rarity}
                onChange={(e) => setRarity(e.target.value)}
              >
                <option value="common">Common</option>
                <option value="uncommon">Uncommon</option>
                <option value="rare">Rare</option>
                <option value="very rare">Very Rare</option>
                <option value="legendary">Legendary</option>
              </select>
            </div>
            <div className="field">
              <label htmlFor="slot">Slot</label>
              <select
                id="slot"
                value={slot}
                onChange={(e) => setSlot(e.target.value)}
              >
                <option value="weapon">Weapon</option>
                <option value="armor">Armor</option>
                <option value="wondrous item">Wondrous Item</option>
                <option value="ring">Ring</option>
                <option value="amulet">Amulet</option>
                <option value="consumable">Consumable</option>
              </select>
            </div>
          </div>
          <div className="field">
            <label htmlFor="theme">Theme / Flavor</label>
            <textarea
              id="theme"
              placeholder="E.g. necrotic chestplate that revives the wearer once per long rest..."
              value={theme}
              onChange={(e) => setTheme(e.target.value)}
            />
          </div>
          {error && (
            <div style={{ color: "#b0423a", fontSize: "0.8rem" }}>{error}</div>
          )}
          <div className="auth-actions">
            <button
              className="btn btn-primary"
              type="submit"
              disabled={loading}
            >
              {loading ? "Enchanting..." : "Generate Item"}
            </button>
          </div>
        </form>
        <div className="card">
          <div className="card-header">
            <div className="card-title">Result</div>
           {item && (
  <span className="badge badge-gold">
    {item.rarity} · {item.type}
    {item.baseDamage ? ` (${item.baseDamage.dice})` : ""}
    {item.attunement ? " · requires attunement" : ""}
  </span>
)}
          </div>
          <div className="scroll-section">
            {item ? (
              <div className="stat-block">
                <h3>{item.name}</h3>
                <div style={{ fontSize: "0.85rem", marginBottom: "0.45rem" }}>
                  {item.description}
                </div>
                {item.mechanicalEffects.length > 0 && (
                  <div style={{ marginBottom: "0.45rem" }}>
                    <div className="stat-label">Effects</div>
                    <ul>
                      {item.mechanicalEffects.map((e) => (
                        <li key={e}>{e}</li>
                      ))}
                    </ul>
                  </div>
                )}
                
                {/* ARMOR STATS */}
                {item.armorClass !== null && item.armorClass !== undefined !== null && (
                  <div className="stat-line">
                    <span className="stat-label">Armor</span>
                    <span>
                      AC {item.armorClass}
                      {item.armorCategory ? ` (${item.armorCategory})` : ""}
                      {item.requiresStrength && item.strengthRequirement
                        ? ` · STR ${item.strengthRequirement}`
                        : ""}
                      {item.stealthDisadvantage ? " · Stealth Disadvantage" : ""}
                    </span>
                  </div>
                )}

                <div className="stat-line">
                  <span className="stat-label">Value</span>
                  <span>
                    {item.value.gp} gp{" "}
                    {item.value.notes && `(${item.value.notes})`}
                  </span>
                </div>
              </div>
            ) : (
              <div
                style={{
                  fontSize: "0.85rem",
                  color: "#5b4a34"
                }}
              >
                Generate a magic item on the left to see it here.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DMItemPage;
