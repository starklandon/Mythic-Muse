import React from "react";
import { Outlet } from "react-router-dom";
import { TabNav } from "../components/TabNav";

const PlayerDashboard: React.FC = () => {
  return (
    <>
      <TabNav mode="player" />
      <Outlet />
    </>
  );
};

export default PlayerDashboard;
