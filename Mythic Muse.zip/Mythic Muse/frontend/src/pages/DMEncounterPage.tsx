import React, { useState } from "react";
import { api } from "../api/client";
import type { Encounter, Creature } from "../api/types";
import { HPTracker } from "../components/HPTracker";

// Modifier helper
const abilityMod = (score: number): string => {
  const mod = Math.floor((score - 10) / 2);
  return mod >= 0 ? `+${mod}` : `${mod}`;
};

const DMEncounterPage: React.FC = () => {
  const [expandedIndex, setExpandedIndex] = useState<number | null>(null);
  const [hpState, setHpState] = useState<Record<number, number>>({});

  const [partyLevel, setPartyLevel] = useState(5);
  const [partySize, setPartySize] = useState(4);
  const [difficulty, setDifficulty] = useState("medium");
  const [biome, setBiome] = useState("forest");
  const [theme, setTheme] = useState("");

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [encounter, setEncounter] = useState<Encounter | null>(null);

  // ----------------------------
  // Generate Encounter
  // ----------------------------
  const generateEncounter = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const res = await api.post("/api/encounters/generate", {
        partyLevel,
        partySize,
        difficulty,
        biome,
        theme
      });

      const enc: Encounter = res.data.encounter;
      setEncounter(enc);

      // ------------------------------
      // FIXED — Initialize HP correctly
      // ------------------------------
      const initialHp: Record<number, number> = {};
      enc.creatures.forEach((c: Creature, index: number) => {
        initialHp[index] = c.hitPoints?.average ?? 1;
      });
      setHpState(initialHp);

    } catch (err: any) {
      setError(err?.response?.data?.error || "Failed to generate encounter");
    } finally {
      setLoading(false);
    }
  };

  // ----------------------------
  // Render
  // ----------------------------
  return (
    <div className="book-page">

      {/* HEADER */}
      <div className="page-header">
        <div>
          <div className="page-title">Encounter Generator</div>
          <div className="page-subtitle">
            Build balanced, thematic combats tailored to your party.
          </div>
        </div>
      </div>

      <div className="page-body">

        {/* ------------------------- */}
        {/* FORM */}
        {/* ------------------------- */}
        <form className="card" onSubmit={generateEncounter}>
          <div className="card-header">
            <div className="card-title">Parameters</div>
          </div>

          <div className="field-grid">
            <div className="field">
              <label>Party Level</label>
              <input
                type="number"
                min={1}
                max={20}
                value={partyLevel}
                onChange={(e) => setPartyLevel(Number(e.target.value))}
              />
            </div>

            <div className="field">
              <label>Party Size</label>
              <input
                type="number"
                min={1}
                max={8}
                value={partySize}
                onChange={(e) => setPartySize(Number(e.target.value))}
              />
            </div>

            <div className="field">
              <label>Difficulty</label>
              <select
                value={difficulty}
                onChange={(e) => setDifficulty(e.target.value)}
              >
                <option value="easy">Easy</option>
                <option value="medium">Medium</option>
                <option value="hard">Hard</option>
                <option value="deadly">Deadly</option>
              </select>
            </div>

            <div className="field">
              <label>Environment</label>
              <select value={biome} onChange={(e) => setBiome(e.target.value)}>
                <option value="forest">Forest</option>
                <option value="dungeon">Dungeon</option>
                <option value="desert">Desert</option>
                <option value="swamp">Swamp</option>
                <option value="mountain">Mountain</option>
                <option value="urban">Urban</option>
                <option value="coastal">Coastal</option>
              </select>
            </div>
          </div>

          <div className="field">
            <label>Theme / Hook</label>
            <textarea
              placeholder="E.g. corrupted dryads defending a fallen fey gate..."
              value={theme}
              onChange={(e) => setTheme(e.target.value)}
            />
          </div>

          {error && (
            <div style={{ color: "#b0423a", fontSize: "0.8rem" }}>
              {error}
            </div>
          )}

          <div className="auth-actions">
            <button className="btn btn-primary" disabled={loading}>
              {loading ? "Plotting ambush..." : "Generate Encounter"}
            </button>
          </div>
        </form>

        {/* ------------------------- */}
        {/* RESULT PANEL */}
        {/* ------------------------- */}
        <div className="card">
          <div className="card-header">
            <div className="card-title">Result</div>

            {encounter && (
              <span className="badge badge-blue">
                {encounter.difficulty} · Lv {encounter.party.level} ×{" "}
                {encounter.party.size}
              </span>
            )}
          </div>

          <div className="scroll-section">

            {!encounter && (
              <div style={{ fontSize: "0.85rem", color: "#5b4a34" }}>
                Generate an encounter on the left to see it here.
              </div>
            )}

            {encounter && (
              <div>

                <h3>{encounter.name}</h3>

                <div className="stat-line">
                  <span className="stat-label">Environment</span>
                  <span>{encounter.environment}</span>
                </div>

                {encounter.theme && (
                  <div style={{ marginTop: "0.5rem", fontSize: "0.85rem" }}>
                    <strong>Theme:</strong> {encounter.theme}
                  </div>
                )}

                {/* ------------------------- */}
                {/* CREATURE LIST */}
                {/* ------------------------- */}
                <div style={{ marginTop: "1rem" }}>
                  <div className="stat-label">Creatures</div>

                  {encounter.creatures.map((creature, index) => {
                    const expanded = expandedIndex === index;

                    return (
                      <div key={index} className="card" style={{ marginTop: "0.5rem" }}>

                        {/* HEADER (click to expand) */}
                        <div
                          className="card-header"
                          style={{ cursor: "pointer" }}
                          onClick={() => setExpandedIndex(expanded ? null : index)}
                        >
                          <div className="card-title">
                            {creature.name} (CR {creature.cr})
                          </div>

                          <div style={{ fontSize: "0.85rem" }}>
                            HP: {hpState[index]}/{creature.hitPoints?.average}
                          </div>
                        </div>

                        {/* ------------------------- */}
                        {/* EXPANDED PANEL */}
                        {/* ------------------------- */}
                        {expanded && (
                          <div className="card-body">

                            {/* HP TRACKER */}
                            <HPTracker
                              currentHp={hpState[index]}
                              maxHp={creature.hitPoints?.average}
                              onChange={(values) =>
                                setHpState((prev) => ({
                                  ...prev,
                                  [index]: (values.currentHp ?? 0)
                                }))
                              }
                            />

                            {/* FULL STATBLOCK */}
                            <div className="stat-block">

                              <div className="stat-line">
                                <span className="stat-label">Type</span>
                                <span>
                                  {creature.size} {creature.type},{" "}
                                  {creature.alignment}
                                </span>
                              </div>

                              <div className="stat-line">
                                <span className="stat-label">Armor Class</span>
                                <span>{creature.armorClass}</span>
                              </div>

                              <div className="stat-line">
                                <span className="stat-label">Speed</span>
                                <span>{creature.speed.walk}</span>
                              </div>

                              <div className="stat-line">
                                <span className="stat-label">Abilities</span>
                                <span>
                                  STR {creature.abilities.str} ({abilityMod(creature.abilities.str)}) ·
                                  DEX {creature.abilities.dex} ({abilityMod(creature.abilities.dex)}) ·
                                  CON {creature.abilities.con} ({abilityMod(creature.abilities.con)}) ·
                                  INT {creature.abilities.int} ({abilityMod(creature.abilities.int)}) ·
                                  WIS {creature.abilities.wis} ({abilityMod(creature.abilities.wis)}) ·
                                  CHA {creature.abilities.cha} ({abilityMod(creature.abilities.cha)})
                                </span>
                              </div>

                              {/* Traits */}
                              <div className="section-title">Traits</div>
                              {creature.traits?.map((t, i) => (
                                <div key={i} className="trait">
                                  <strong>{t.name}.</strong> {t.description}
                                </div>
                              ))}

                              {/* Actions */}
                              <div className="section-title">Actions</div>
                              {creature.actions?.map((a, i) => (
                                <div key={i} className="trait">
                                  <strong>{a.name}.</strong> {a.description}
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>

                {/* TACTICS */}
                {encounter.tactics && (
                  <div style={{ marginTop: "1rem" }}>
                    <div className="stat-label">Tactics</div>
                    <div style={{ fontSize: "0.85rem" }}>
                      {encounter.tactics}
                    </div>
                  </div>
                )}

                {/* TREASURE */}
                {encounter.treasure.length > 0 && (
                  <div style={{ marginTop: "1rem" }}>
                    <div className="stat-label">Treasure Hooks</div>
                    <ul>
                      {encounter.treasure.map((t, i) => (
                        <li key={i}>{t}</li>
                      ))}
                    </ul>
                  </div>
                )}

              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DMEncounterPage;
