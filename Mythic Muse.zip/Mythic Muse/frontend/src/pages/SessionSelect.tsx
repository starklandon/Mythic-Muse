import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { api } from "../api/client";
import type { Session } from "../api/types";

const SessionSelect: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [sessions, setSessions] = useState<Session[]>([]);
  const [loading, setLoading] = useState(true);
  const [createName, setCreateName] = useState("");
  const [inviteKey, setInviteKey] = useState("");
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const load = async () => {
      try {
        const res = await api.get("/api/sessions");
        setSessions(res.data.sessions || []);
      } catch (err: any) {
        setError(err?.response?.data?.error || "Failed to load sessions");
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      const res = await api.post("/api/sessions", { name: createName });
      const session = res.data.session as Session;
      setSessions((prev) => [...prev, session]);
      setCreateName("");
    } catch (err: any) {
      setError(err?.response?.data?.error || "Failed to create session");
    }
  };

  const handleJoin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      const res = await api.post("/api/sessions/join", { inviteKey });
      const session = res.data.session as Session;
      const exists = sessions.find((s) => s.id === session.id);
      setSessions(exists ? sessions : [...sessions, session]);
      setInviteKey("");
    } catch (err: any) {
      setError(err?.response?.data?.error || "Failed to join session");
    }
  };

  const goToSession = (session: Session) => {
    if (session.dmId === user?.id) {
      navigate("/dm/creatures", { state: { session } });
    } else {
      navigate("/player/character", { state: { session } });
    }
  };

  return (
    <div className="book-page">
      <div className="page-header">
        <div>
          <div className="page-title">Your Sessions</div>
          <div className="page-subtitle">
            Create a new session as DM or join using an invite key.
          </div>
        </div>
      </div>
      <div className="page-body">
        <div className="card">
          <div className="card-header">
            <div className="card-title">Create Session</div>
          </div>
          <form onSubmit={handleCreate}>
            <div className="field">
              <label htmlFor="sessionName">Session name</label>
              <input
                id="sessionName"
                value={createName}
                onChange={(e) => setCreateName(e.target.value)}
                required
              />
            </div>
            <div className="auth-actions">
              <button className="btn btn-primary" type="submit">
                Create as DM
              </button>
            </div>
          </form>
        </div>
        <div className="card">
          <div className="card-header">
            <div className="card-title">Join Session</div>
          </div>
          <form onSubmit={handleJoin}>
            <div className="field">
              <label htmlFor="inviteKey">Invite key</label>
              <input
                id="inviteKey"
                value={inviteKey}
                onChange={(e) => setInviteKey(e.target.value.toUpperCase())}
                required
              />
            </div>
            <div className="auth-actions">
              <button className="btn btn-primary" type="submit">
                Join as Player
              </button>
            </div>
          </form>
        </div>
        <div className="card" style={{ gridColumn: "1 / -1" }}>
          <div className="card-header">
            <div className="card-title">Continue Session</div>
            {loading && <span>Loading...</span>}
          </div>
          {error && (
            <div style={{ color: "#b0423a", fontSize: "0.8rem" }}>{error}</div>
          )}
          <div className="session-list">
            {sessions.map((s) => (
              <div key={s.id} className="session-item">
                <div>
                  <div className="session-item-title">{s.name}</div>
                  <div className="session-item-meta">
                    DM: {s.dmId === user?.id ? "You" : s.dmId} · Invite:{" "}
                    {s.inviteKey}
                  </div>
                </div>
                <button
                  type="button"
                  className="btn btn-primary"
                  onClick={() => goToSession(s)}
                >
                  Continue
                </button>
              </div>
            ))}
            {!loading && sessions.length === 0 && (
              <div style={{ fontSize: "0.85rem", color: "#5b4a34" }}>
                No sessions yet. Create one as DM or join with an invite key.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SessionSelect;
