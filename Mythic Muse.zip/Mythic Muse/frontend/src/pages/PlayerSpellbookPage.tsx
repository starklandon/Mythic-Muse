import React from "react";

const PlayerSpellbookPage: React.FC = () => {
  return (
    <div className="book-page">
      <div className="page-header">
        <div>
          <div className="page-title">Spellbook</div>
          <div className="page-subtitle">
            A home for your spells with rules text and slot tracking.
          </div>
        </div>
      </div>
      <div className="page-body">
        <div className="card" style={{ gridColumn: "1 / -1" }}>
          <div className="card-header">
            <div className="card-title">Coming Soon</div>
          </div>
          <div style={{ fontSize: "0.85rem", color: "#5b4a34" }}>
            The spellbook page will later display spells and slots calculated
            from your class, level, and level-up choices. For now, we&apos;re
            focusing on the DM generators and HP trackers.
          </div>
        </div>
      </div>
    </div>
  );
};

export default PlayerSpellbookPage;
