import React, { useState } from "react";
import { api } from "../api/client";
import type { Shop } from "../api/types";

const DMShopPage: React.FC = () => {
  const [expandedIndex, setExpandedIndex] = useState<number | null>(null);
  const [tier, setTier] = useState("mid");
  const [goldBudget, setGoldBudget] = useState(1000);
  const [itemTypes, setItemTypes] = useState("mixed");
  const [theme, setTheme] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [shop, setShop] = useState<Shop | null>(null);

  const generateShop = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const res = await api.post("/api/shops/generate", {
        tier,
        goldBudget,
        itemTypes,
        theme
      });
      setShop(res.data.shop);
    } catch (err: any) {
      setError(err?.response?.data?.error || "Failed to generate shop");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="book-page">
      <div className="page-header">
        <div>
          <div className="page-title">Shop Generator</div>
          <div className="page-subtitle">
            Stock a thematic, balanced magic shop with a single click.
          </div>
        </div>
      </div>

      <div className="page-body">
        {/* FORM */}
        <form className="card" onSubmit={generateShop}>
          <div className="card-header">
            <div className="card-title">Parameters</div>
          </div>

          <div className="field-grid">
            <div className="field">
              <label>Shop Tier</label>
              <select value={tier} onChange={(e) => setTier(e.target.value)}>
                <option value="low">Low</option>
                <option value="mid">Mid</option>
                <option value="high">High</option>
                <option value="legendary">Legendary</option>
              </select>
            </div>

            <div className="field">
              <label>Gold Budget</label>
              <input
                type="number"
                min={50}
                value={goldBudget}
                onChange={(e) => setGoldBudget(Number(e.target.value) || 0)}
              />
            </div>

            <div className="field">
              <label>Item Types</label>
              <select
                value={itemTypes}
                onChange={(e) => setItemTypes(e.target.value)}
              >
                <option value="mixed">Mixed</option>
                <option value="weapons">Weapons</option>
                <option value="armor">Armor</option>
                <option value="wondrous">Wondrous</option>
                <option value="potions">Potions</option>
              </select>
            </div>
          </div>

          <div className="field">
            <label>Theme</label>
            <textarea
              placeholder="E.g. fey curiosities, infernal bargains..."
              value={theme}
              onChange={(e) => setTheme(e.target.value)}
            />
          </div>

          {error && (
            <div style={{ color: "#b0423a", fontSize: "0.8rem" }}>{error}</div>
          )}

          <div className="auth-actions">
            <button className="btn btn-primary" disabled={loading}>
              {loading ? "Stocking shelves..." : "Generate Shop"}
            </button>
          </div>
        </form>

        {/* RESULTS */}
        <div className="card">
          <div className="card-header">
            <div className="card-title">Result</div>
            {shop && (
              <span className="badge badge-gold">
                {shop.name} · {shop.tier} tier
              </span>
            )}
          </div>

          <div className="scroll-section">
            {!shop && (
              <div style={{ fontSize: "0.85rem", color: "#5b4a34" }}>
                Generate a shop on the left to see it here.
              </div>
            )}

            {shop && (
              <div className="stat-block">
                {shop.theme && (
                  <div style={{ fontSize: "0.85rem", marginBottom: "0.3rem" }}>
                    <strong>Theme: </strong>
                    {shop.theme}
                  </div>
                )}

                {/* ITEM LIST */}
                {shop.items.map((it, idx) => {
                  const expanded = expandedIndex === idx;
                  const effects = it.mechanicalEffects || [];

                  return (
                    <div
                      key={`${it.name}-${idx}`}
                      style={{
                        borderBottom: "1px solid rgba(0,0,0,0.1)",
                        padding: "0.4rem 0"
                      }}
                    >
                      <div
                        style={{
                          display: "flex",
                          justifyContent: "space-between",
                          cursor: "pointer"
                        }}
                        onClick={() =>
                          setExpandedIndex(expanded ? null : idx)
                        }
                      >
                        <div>
                          <div style={{ fontWeight: 600 }}>{it.name}</div>
                          <div style={{ color: "#5b4a34", fontSize: "0.8rem" }}>
                            {it.description}
                          </div>
                        </div>
                        <div style={{ whiteSpace: "nowrap" }}>
                          {it.price} gp
                        </div>
                      </div>
{expanded && (
  <div
    style={{
      marginTop: "0.5rem",
      background: "#f9f4e8",
      padding: "0.6rem",
      borderRadius: "4px",
      fontSize: "0.85rem"
    }}
  >
    {/* BASE DAMAGE */}
    {it.baseDamage?.dice && (
      <div>
        <strong>Base Damage:</strong>{" "}
        {it.baseDamage.dice} ({it.baseDamage.type || "unknown"})
      </div>
    )}

    {/* MAGICAL DAMAGE */}
    {it.magicalDamage && (
      <div>
        <strong>Magical Effect:</strong> {it.magicalDamage}
      </div>
    )}

    {/* MECHANICAL EFFECTS */}
    {Array.isArray(it.mechanicalEffects) && it.mechanicalEffects.length > 0 && (
      <div style={{ marginTop: "0.4rem" }}>
        <strong>Mechanical Effects:</strong>
        <ul>
          {it.mechanicalEffects.map((ef, i) => (
            <li key={i}>{ef}</li>
          ))}
        </ul>
      </div>
    )}

    {/* SPELL EFFECTS */}
    {it.spellEffects && (
      <div style={{ marginTop: "0.4rem" }}>
        <strong>Spell Effect:</strong>
        <div>{it.spellEffects}</div>
      </div>
    )}

    {/* RARITY */}
    <div style={{ marginTop: "0.4rem" }}>
      <strong>Rarity:</strong> {it.rarity || "unknown"}
    </div>

    {/* TAGS */}
    {Array.isArray(it.tags) && it.tags.length > 0 && (
      <div style={{ marginTop: "0.5rem" }}>
        <strong>Tags:</strong> {it.tags.join(", ")}
      </div>
    )}

    {/* PRICE DETAILS */}
    {typeof it.price === "number" && (
      <div style={{ marginTop: "0.5rem" }}>
        <strong>Price:</strong> {it.price} gp
      </div>
    )}

    {/* SLOT */}
    {it.slot && (
      <div style={{ marginTop: "0.5rem" }}>
        <strong>Slot:</strong> {it.slot}
      </div>
    )}

    {/* ATTUNEMENT */}
    {"attunement" in it && (
      <div style={{ marginTop: "0.5rem" }}>
        <strong>Requires Attunement:</strong>{" "}
        {it.attunement ? "Yes" : "No"}
      </div>
    )}
  </div>
)}

                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DMShopPage;
