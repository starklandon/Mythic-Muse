import React, { useState } from "react";
import { api } from "../api/client";

interface LevelupAdvice {
  summary: string;
  recommendedFeatures: string[];
  recommendedSpells: string[];
  recommendedFeats: string[];
  playstyleTips: string[];
}

const PlayerLevelUpPage: React.FC = () => {
  const [currentLevel, setCurrentLevel] = useState(5);
  const [characterClass, setCharacterClass] = useState("wizard");
  const [subclass, setSubclass] = useState("");
  const [partyRole, setPartyRole] = useState("controller");
  const [preferences, setPreferences] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [advice, setAdvice] = useState<LevelupAdvice | null>(null);

  const requestAdvice = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const res = await api.post("/api/levelup/advice", {
        currentLevel,
        characterClass,
        subclass,
        partyRole,
        preferences
      });
      setAdvice(res.data.advice);
    } catch (err: any) {
      setError(err?.response?.data?.error || "Failed to get advice");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="book-page">
      <div className="page-header">
        <div>
          <div className="page-title">Level-Up Assistant</div>
          <div className="page-subtitle">
            Get tailored 5e-inspired guidance for your next level.
          </div>
        </div>
      </div>
      <div className="page-body">
        <form className="card" onSubmit={requestAdvice}>
          <div className="card-header">
            <div className="card-title">Character Overview</div>
          </div>
          <div className="field-grid">
            <div className="field">
              <label htmlFor="currentLevel">Current Level</label>
              <input
                id="currentLevel"
                type="number"
                min={1}
                max={20}
                value={currentLevel}
                onChange={(e) =>
                  setCurrentLevel(Number(e.target.value) || currentLevel)
                }
              />
            </div>
            <div className="field">
              <label htmlFor="class">Class</label>
              <select
                id="class"
                value={characterClass}
                onChange={(e) => setCharacterClass(e.target.value)}
              >
                <option value="barbarian">Barbarian</option>
                <option value="bard">Bard</option>
                <option value="cleric">Cleric</option>
                <option value="druid">Druid</option>
                <option value="fighter">Fighter</option>
                <option value="monk">Monk</option>
                <option value="paladin">Paladin</option>
                <option value="ranger">Ranger</option>
                <option value="rogue">Rogue</option>
                <option value="sorcerer">Sorcerer</option>
                <option value="warlock">Warlock</option>
                <option value="wizard">Wizard</option>
              </select>
            </div>
          </div>
          <div className="field-grid">
            <div className="field">
              <label htmlFor="subclass">Subclass</label>
              <input
                id="subclass"
                value={subclass}
                onChange={(e) => setSubclass(e.target.value)}
                placeholder="Evocation, Battle Master, etc."
              />
            </div>
            <div className="field">
              <label htmlFor="partyRole">Party Role</label>
              <select
                id="partyRole"
                value={partyRole}
                onChange={(e) => setPartyRole(e.target.value)}
              >
                <option value="striker">Striker</option>
                <option value="controller">Controller</option>
                <option value="defender">Defender</option>
                <option value="support">Support</option>
                <option value="mixed">Mixed</option>
              </select>
            </div>
          </div>
          <div className="field">
            <label htmlFor="preferences">Preferences</label>
            <textarea
              id="preferences"
              placeholder="E.g. I prefer blasting spells, not too much bookkeeping, like controlling the battlefield..."
              value={preferences}
              onChange={(e) => setPreferences(e.target.value)}
            />
          </div>
          {error && (
            <div style={{ color: "#b0423a", fontSize: "0.8rem" }}>{error}</div>
          )}
          <div className="auth-actions">
            <button
              className="btn btn-primary"
              type="submit"
              disabled={loading}
            >
              {loading ? "Consulting the fates..." : "Get Level-Up Advice"}
            </button>
          </div>
        </form>
        <div className="card">
          <div className="card-header">
            <div className="card-title">Advice</div>
          </div>
          <div className="scroll-section">
            {advice ? (
              <div className="stat-block">
                <div style={{ marginBottom: "0.6rem" }}>{advice.summary}</div>
                {advice.recommendedFeatures.length > 0 && (
                  <div style={{ marginBottom: "0.5rem" }}>
                    <div className="stat-label">Features</div>
                    <ul>
                      {advice.recommendedFeatures.map((f) => (
                        <li key={f}>{f}</li>
                      ))}
                    </ul>
                  </div>
                )}
                {advice.recommendedSpells.length > 0 && (
                  <div style={{ marginBottom: "0.5rem" }}>
                    <div className="stat-label">Spells</div>
                    <ul>
                      {advice.recommendedSpells.map((s) => (
                        <li key={s}>{s}</li>
                      ))}
                    </ul>
                  </div>
                )}
                {advice.recommendedFeats.length > 0 && (
                  <div style={{ marginBottom: "0.5rem" }}>
                    <div className="stat-label">Feats</div>
                    <ul>
                      {advice.recommendedFeats.map((f) => (
                        <li key={f}>{f}</li>
                      ))}
                    </ul>
                  </div>
                )}
                {advice.playstyleTips.length > 0 && (
                  <div>
                    <div className="stat-label">Playstyle Tips</div>
                    <ul>
                      {advice.playstyleTips.map((t) => (
                        <li key={t}>{t}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            ) : (
              <div
                style={{
                  fontSize: "0.85rem",
                  color: "#5b4a34"
                }}
              >
                Fill out your class and preferences on the left, then request
                advice to see tailored suggestions here.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PlayerLevelUpPage;
