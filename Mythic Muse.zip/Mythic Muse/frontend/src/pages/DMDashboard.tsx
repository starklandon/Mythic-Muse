import React from "react";
import { Outlet } from "react-router-dom";
import { TabNav } from "../components/TabNav";

const DMDashboard: React.FC = () => {
  return (
    <>
      <TabNav mode="dm" />
      <Outlet />
    </>
  );
};

export default DMDashboard;
