export interface Creature {
  name: string;
  cr: number;
  size: string;
  type: string;
  alignment: string;
  armorClass: number;
  hitPoints: {
    average: number;
    formula: string;
  };
  currentHp: number;
  speed: {
    walk: string;
    fly: string | null;
    swim: string | null;
    climb: string | null;
    burrow: string | null;
  };
  abilities: {
    str: number;
    dex: number;
    con: number;
    int: number;
    wis: number;
    cha: number;
  };
  savingThrows: Record<string, number>;
  skills: Record<string, number>;
  senses: string[];
  languages: string[];
  traits: { name: string; description: string }[];
  actions: {
    name: string;
    type: string;
    description: string;
    attackBonus: number | null;
    damage: string | null;
    saveDC: number | null;
  }[];
  reactions: { name: string; description: string }[];
  legendaryActions: { name: string; description: string }[];
  environmentTags: string[];
}

export interface MagicItem {
  name: string;
  type: string;
  rarity: string;

  baseDamage?: {
    dice: string;
    type: string;
  };

  magicalDamage?: string | null;

  attunement: boolean;
  slot: string | null;
  description: string;
  mechanicalEffects: string[];
  value: {
    gp: number;
    notes: string;
  };
  charges: number | null;
  consumable: boolean;
  stackable: boolean;
}


export interface EncounterCreature {
  name: string;
  count: number;
  cr: number;
  role: string | null;
}

export interface Encounter {
  name: string;
  theme: string | null;
  environment: string | null;
  difficulty: "easy" | "medium" | "hard" | "deadly" | string;
  party: {
    level: number;
    size: number;
  };
  creatures: EncounterCreature[];
  tactics: string;
  treasure: string[];
  notes: string;
}

export interface ShopItem {
  name: string;
  type: string;
  rarity: string;
  price: number;
  description: string;
  tags: string[];
}

export interface Shop {
  name: string;
  tier: "low" | "mid" | "high" | "legendary" | string;
  goldBudget: number;
  theme: string | null;
  items: ShopItem[];
}

export interface Character {
  id: string;
  userId: string;
  sessionId: string;
  name: string;
  race: string;
  class: string;
  subclass: string | null;
  level: number;
  abilityScores: {
    str: number;
    dex: number;
    con: number;
    int: number;
    wis: number;
    cha: number;
  };
  maxHp: number;
  currentHp: number;
  tempHp: number;
  armorClass: number;
  speed: number;
  proficiencyBonus: number;
  spellcasting: {
    spellcastingClass: string | null;
    spellSlots: Record<string, number>;
    knownSpells: string[];
    preparedSpells: string[];
  };
  inventory: {
    name: string;
    type?: string;
    description?: string;
    quantity: number;
  }[];
  notes: string;
}

export interface Session {
  id: string;
  name: string;
  dmId: string;
  inviteKey: string;
  createdAt: string;
  updatedAt: string;
  playerIds: string[];
}

export interface User {
  id: string;
  email: string;
}
