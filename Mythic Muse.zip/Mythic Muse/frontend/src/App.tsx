import React from "react";
import { Routes, Route, Navigate, useNavigate } from "react-router-dom";
import { AuthProvider, useAuth } from "./context/AuthContext";
import { TomeLayout } from "./components/TomeLayout";
import AuthLogin from "./pages/AuthLogin";
import AuthRegister from "./pages/AuthRegister";
import SessionSelect from "./pages/SessionSelect";
import DMLootPage from "./pages/DMLootPage";
import DMDashboard from "./pages/DMDashboard";
import PlayerDashboard from "./pages/PlayerDashboard";
import DMCreaturePage from "./pages/DMCreaturePage";
import DMItemPage from "./pages/DMItemPage";
import DMEncounterPage from "./pages/DMEncounterPage";
import DMShopPage from "./pages/DMShopPage";
import PlayerCharacterPage from "./pages/PlayerCharacterPage";
import PlayerInventoryPage from "./pages/PlayerInventoryPage";
import PlayerSpellbookPage from "./pages/PlayerSpellbookPage";
import PlayerLevelUpPage from "./pages/PlayerLevelUpPage";

const RequireAuth: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="app-shell">
        <div className="app-inner">
          <div style={{ padding: "2rem" }}>Loading...</div>
        </div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  return <>{children}</>;
};

const Shell: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const rightHeader = user ? (
    <>
      <span style={{ fontSize: "0.85rem" }}>{user.email}</span>
      <button
        type="button"
        className="btn btn-ghost"
        onClick={() => navigate("/sessions")}
      >
        Sessions
      </button>
      <button
        type="button"
        className="btn btn-ghost"
        onClick={() => {
          logout();
          navigate("/login");
        }}
      >
        Log Out
      </button>
    </>
  ) : (
    <>
      <button
        type="button"
        className="btn btn-ghost"
        onClick={() => navigate("/login")}
      >
        Sign In
      </button>
      <button
        type="button"
        className="btn btn-primary"
        onClick={() => navigate("/register")}
      >
        Get Started
      </button>
    </>
  );

  return <TomeLayout rightHeader={rightHeader}>{children}</TomeLayout>;
};

const AppRoutes: React.FC = () => {
  return (
    <Routes>
      <Route
        path="/login"
        element={
          <Shell>
            <AuthLogin />
          </Shell>
        }
      />
      <Route
        path="/register"
        element={
          <Shell>
            <AuthRegister />
          </Shell>
        }
      />
      <Route
        path="/sessions"
        element={
          <RequireAuth>
            <Shell>
              <SessionSelect />
            </Shell>
          </RequireAuth>
        }
      />
      <Route
        path="/dm"
        element={
          <RequireAuth>
            <Shell>
              <DMDashboard />
            </Shell>
          </RequireAuth>
        }
      >
        <Route index element={<Navigate to="/dm/creatures" replace />} />
        <Route path="creatures" element={<DMCreaturePage />} />
        <Route path="items" element={<DMItemPage />} />
        <Route path="encounters" element={<DMEncounterPage />} />
        <Route path="shops" element={<DMShopPage />} />
      </Route>
      <Route
        path="/player"
        element={
          <RequireAuth>
            <Shell>
              <PlayerDashboard />
            </Shell>
          </RequireAuth>
        }
      >
        <Route index element={<Navigate to="/player/character" replace />} />
        <Route path="character" element={<PlayerCharacterPage />} />
        <Route path="inventory" element={<PlayerInventoryPage />} />
        <Route path="spellbook" element={<PlayerSpellbookPage />} />
        <Route path="levelup" element={<PlayerLevelUpPage />} />
      </Route>
      <Route path="/" element={<Navigate to="/sessions" replace />} />
      <Route path="*" element={<Navigate to="/sessions" replace />} />
      <Route path="/dm/loot" element={<DMLootPage />} />
      </Routes>
  );
};

const App: React.FC = () => {
  return (
    <AuthProvider>
      <AppRoutes />
    </AuthProvider>
  );
};

export default App;
